# private/ — private vehicles

**Everything that is not public transport.** Cars, taxis, minibuses operating as
shared taxis, pickups, light goods vehicles, trucks and motorcycles.

---

## What "private" means here

These vehicles share three properties:

1. **They choose their own route.** No fixed path, no timetable.
2. **They carry few people.** ~1.4 per car, ~2.5 per shared taxi.
3. **They respond to congestion by re-routing** — and that re-routing is what
   creates the second-order effects the model exists to predict.

The contrast with `public/` is the point: a bus cannot re-route around a closure,
so closing a road affects buses completely differently from cars. Modelling them
together without distinguishing them produces an answer that is wrong for both.

---

## Files

| File | Covers |
|---|---|
| [P01](P01%20vehicle-classes-and-pcu.md) | Vehicle mix and passenger-car equivalents |
| [P02](P02%20occupancy-and-vehicle-demand.md) | How many people, how many vehicles |
| [P03](P03%20parking-search-time.md) | The hidden delay at the end of every trip |
| [P04](P04%20user-context.md) | Preferences, urgency, vehicle restrictions |
| [P05](P05%20alternative-routes.md) | Presenting options and tradeoffs |

---

## The composition of Sulaimani traffic

This mix drives P01 and it is **not** the same as a European city. Assume:

| Class | Share of vehicles | PCU | Notes |
|---|---|---|---|
| Private car | 55% | 1.0 | |
| Taxi (private-hire) | 12% | 1.0 | high mileage, low occupancy |
| Shared taxi / minibus | 10% | 1.5 | informal transit, fixed-ish routes |
| Pickup / light goods | 12% | 1.5 | commercial |
| Truck / heavy | 5% | 3.0 | restricted hours in the centre |
| Motorcycle / scooter | 5% | 0.4 | delivery bikes, growing |
| Bicycle / cart | 1% | 0.5 | |

**The informal shared taxi is the local specific.** It behaves like a bus
(fixed corridor, multiple stops) and like a car (no timetable, re-routes freely).
It sits between the two folders and should be modelled as a **private vehicle
with high occupancy and frequent stops** — closer to P02 than to B02.

Get this wrong and a Sulaimani planner will notice immediately.

---

## What every private vehicle adds to the model

| Effect | Where |
|---|---|
| Demand, scaled by PCU | P01 → F13 |
| People moved, for the equity story | P02 |
| Extra delay for parking at the destination | P03 |
| Route preferences | P04 → F11 |
| Displayed alternatives | P05 |
