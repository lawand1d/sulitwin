# P03 — Parking search time

**User context → the delay nobody counts**

## PURPOSE

Adds the time a driver spends cruising for a space at the destination. It is real
delay, it is caused by traffic, and it is almost always omitted from models.

In a dense commercial area it can exceed the entire journey's moving time.

---

## EQUATION

```
t_park = t_base × ( 1 + γ · ( occupancy_ratio )^2 )

occupancy_ratio = parked_vehicles / parking_spaces
```

| Symbol | Meaning | Value |
|---|---|---|
| `t_base` | time to park when spaces are free | 20 s |
| `γ` | sensitivity to saturation | 6.0 |

| `occupancy_ratio` | Extra search time | Typical situation |
|---|---|---|
| 0.0 – 0.5 | ~0 | easy |
| 0.7 | +1.0 min | filling up |
| 0.85 | +2.3 min | circling begins |
| 0.95 | +5.2 min | **cruising dominates** |
| 1.00+ | +8 min and rising | no space will be found |

**Note the shape: quadratic.** Parking delay is negligible until it suddenly is
not. That is why it gets ignored — it does not appear in average conditions, only
in the ones that matter.

---

## Estimating spaces and parked vehicles

We have no parking inventory. Estimate from land use:

```
spaces(area)     = Σ (buildingArea × spacesPerM2[useType])
parkedVehicles   = arrivals(area) × avgParkingDuration
```

| Land use | `spacesPerM2` | Source |
|---|---|---|
| Retail / bazaar | 0.030 | ESTIMATED |
| Office | 0.020 | ESTIMATED |
| Residential | 0.012 | ESTIMATED |
| Mixed use | 0.022 | ESTIMATED |
| Kerbside (per km of road) | 25 spaces | ESTIMATED |

`avgParkingDuration` by use: retail 40 min, office 6 h, residential overnight.

---

## Where it enters the model

```
t_total = t_link + d_intersection + d_queue + t_park      (F13)
```

Parking time belongs **only to the last link** of a trip. Adding it to every link
would multiply the error.

For the network indicator, parking delay is included. For a through-route it is
excluded. Distinguish the two cases explicitly.

---

## CRUISING TRAFFIC FEEDS BACK

Cruising vehicles are traffic. They add to `q` on the streets around the
destination:

```
q_extra(link near destination) += cruisingVehicles × circulatingShare
```

This creates a genuine feedback: full parking makes streets busier, which makes
parking slower. It is a real effect and a satisfying one to demonstrate — but
**implement it only if the iteration is stable.** If it oscillates, disable the
feedback and note the limitation rather than shipping a model that jitters.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `t_base` | free-space park time | 20 s | ESTIMATED | observation |
| `γ` | saturation sensitivity | 6.0 | ESTIMATED | parking study |
| `spacesPerM2` | land-use ratios | table above | ESTIMATED | parking inventory |
| `avgParkingDuration` | by use | table above | ESTIMATED | parking survey |
| `circulatingShare` | cruisers as traffic | 0.25 | ESTIMATED | observation |

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `occupancyRatio` | number, 0–1+ |
| `landUse` | object, by type |
| `arrivals` | number |

| Output | Type |
|---|---|
| `parkingSearchSeconds(ratio)` | number |
| `parkingCapacity(area)` | number, spaces |
| `parkingPressure(area, t)` | number, ratio |

---

## CODE SHAPE

```
parkingSearchSeconds(occupancyRatio) -> number
parkingCapacity(buildings, roads)    -> number
parkingPressure(area, t, arrivals)   -> number
PARKING_PARAMS                       -> exported
```

**Constraint:** must be monotone non-decreasing and must not explode. Cap at
15 minutes — beyond that drivers give up, park illegally, or leave, and the
formula no longer describes reality.

---

## VALIDATION

| Test | Expectation |
|---|---|
| ratio 0 | returns `t_base` exactly |
| ratio 1.0 | 6 – 10 min |
| ratio 2.0 | capped at 15 min |
| Monotonicity | never decreases |
| Negative ratio | clamped to 0, no error |

---

## NOTES

- **This is the most under-modelled delay in urban traffic.** Journeys are
  measured kerb-to-kerb and the search at the end is invisible. In a bazaar
  district it can be a third of the trip.

- It is also the most **policy-relevant** number here. Parking pricing, park-and-
  ride, and delivery bays all act on this term, and the model can now show what
  they would buy. That turns a traffic model into a parking-policy tool.

- Keep the cruising feedback behind a flag. It is the kind of coupling that makes
  a demo look brilliant when it works and unstable when it does not.
