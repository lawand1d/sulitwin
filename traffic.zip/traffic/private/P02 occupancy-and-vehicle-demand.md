# P02 — Occupancy and vehicle demand

## PURPOSE

Converts **people** into **vehicles**, and back. This is the bridge between a
planning question ("how do 12,000 people get to work?") and a traffic question
("how many cars is that?").

It is also the file that makes the equity comparison possible — cost per person,
not per vehicle.

---

## EQUATION

### People → vehicles

```
N_vehicles = N_people × modeShare_car / occupancy_car
```

### People moved per road

```
personsPerHour = q_c × occupancy_c
```

### The comparison that matters

```
personDelay = Σ_c ( delay_c × occupancy_c × q_c )
```

This is the number that makes a bus lane defensible. One bus delayed by 2 minutes
with 40 people aboard is 80 person-minutes. Forty cars delayed by 2 minutes with
1.4 people each is 112 person-minutes — but the bus carries those 40 people in
**one** vehicle, using a fraction of the road space.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `occupancy_car` | persons per private car | **1.4** | ESTIMATED | roadside occupancy survey |
| `occupancy_taxi` | persons per taxi | 1.3 | ESTIMATED | survey |
| `occupancy_shared` | persons per shared taxi | 6.0 | ESTIMATED | survey |
| `occupancy_light` | persons per pickup | 1.6 | ESTIMATED | survey |
| `occupancy_truck` | persons per truck | 1.2 | ESTIMATED | survey |
| `occupancy_moto` | persons per motorcycle | 1.1 | ESTIMATED | survey |
| `modeShare_car` | car share of trips | 0.42 | ESTIMATED | travel survey |
| `modeShare_taxi` | taxi share | 0.18 | ESTIMATED | travel survey |
| `modeShare_bus` | bus + shared taxi share | 0.28 | ESTIMATED | travel survey |
| `modeShare_walk` | walking share | 0.10 | ESTIMATED | travel survey |
| `modeShare_other` | other | 0.02 | ESTIMATED | travel survey |

Mode shares must sum to 1.0.

**Occupancy 1.4 is the highest-leverage number in this file.** It scales every
person-based conclusion. A roadside count over two hours settles it, and that is
a realistic half-day study.

---

## Occupancy varies by trip purpose

A refinement worth having, because it changes peak conclusions:

| Trip purpose | Occupancy | When |
|---|---|---|
| Commute to work | 1.15 | morning peak |
| School run | 2.10 | 07:30–08:30, 13:00–14:00 |
| Shopping | 1.60 | midday, evening |
| Social / visiting | 3.20 | evening, Thursday, Friday |
| Commercial | 1.50 | all day |

```
occupancy(t, dayType) = Σ_purpose ( purposeShare × occupancy_purpose )
```

**The school run is why morning occupancy is higher than the average** — and why
school holidays change traffic so much, which connects to F03.

---

## INPUTS

| Input | Type |
|---|---|
| `people` | number |
| `mode` | string, optional |
| `t`, `dayType` | for purpose-weighted occupancy |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `vehiclesFrom(people, mode)` | number | |
| `personsMoved(q, mode)` | number | |
| `personDelay(delaySeconds, q, mode)` | number | person-seconds |
| `occupancyAt(t, dayType)` | number | time-weighted |

---

## CODE SHAPE

```
vehiclesFrom(people, mode)          -> number
personsMoved(q, mode)               -> number
personDelay(seconds, q, mode)       -> number
occupancyAt(t, dayType)             -> number
OCCUPANCY, MODE_SHARE, PURPOSE_MIX  -> exported tables
```

**Constraint:** shares and purpose mix must each sum to 1.0. Assert on load.

---

## VALIDATION

| Test | Expectation |
|---|---|
| Mode shares | sum to 1.0 ± 1e-6 |
| Purpose mix | sums to 1.0 ± 1e-6 |
| `vehiclesFrom(1400, 'car')` | 1000 |
| `personsMoved(1000, 'car')` | 1400 (round trip) |
| `occupancyAt(8, weekday)` | > overall mean — school run present |
| `occupancyAt(8, friday)` | lower — no school run |
| `personDelay` | positive for positive delay |

---

## NOTES

- **This is the equity file.** Every argument about who benefits from a change
  runs through here. A model that reports only vehicle delay systematically
  favours cars, because cars are the least efficient way to move people and
  therefore generate the most delay per person moved.

- **State the mode shares when presenting any person-based conclusion.** "A bus
  lane saves 400 person-hours a day" depends entirely on the assumed bus share.
  Give the number *and* the assumption in the same sentence — that is what makes
  it defensible rather than merely persuasive.

- **Walking at 10%** matters more than it looks. Pedestrian signal delay (F07)
  and street shade (the heat model) both affect whether that 10% is realistic.
  The traffic model and the urban-design model are connected through this row.
