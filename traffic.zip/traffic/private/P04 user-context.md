# P04 — User context

**User context → preferred route type, vehicle type, time constraints, history**

## PURPOSE

Modifies route choice and travel cost per user. This is what makes the model
answer *"what should **I** do"* rather than *"what does the average vehicle do"*.

It is the smallest file in the model and the one that makes the output feel
personal.

---

## EQUATION

User context modifies the **generalised cost weights** used by F11:

```
C_user = w_time·T + w_dist·D + w_toll·F + w_risk·R + w_turn·N + w_slope·S
```

where each weight is scaled by the user's profile.

---

## 1. Route preference

| Preference | `w_time` | `w_dist` | `w_risk` | `w_turn` | Effect |
|---|---|---|---|---|---|
| **Fastest** | 1.00 | 0.35 | 2.5 | 0.20 | defaults |
| **Shortest** | 0.60 | 0.90 | 2.0 | 0.15 | prefers direct distance |
| **Safest** | 0.90 | 0.30 | 8.0 | 0.50 | avoids incidents and junctions |
| **Easiest** | 1.00 | 0.40 | 3.0 | 1.20 | fewest turns, avoids hills |
| **Avoid hills** | 1.00 | 0.35 | 2.5 | 0.20 | adds `w_slope = 4.0` |

`w_slope` uses the DEM gradient. On a hilly city this is a preference people
genuinely hold, and it is a feature no flat-city model can offer.

---

## 2. Vehicle type

| Type | Restrictions | Weight change |
|---|---|---|
| Car | none | — |
| Taxi | may use bus lanes if permitted | bus-lane access flag |
| Shared taxi / minibus | frequent stops | +dwell (see B02) |
| Pickup / light goods | centre restrictions 07:00–20:00 | route excludes restricted links in hours |
| Truck | centre banned 07:00–20:00, weight limits | route excludes banned links |
| Motorcycle | filters through congestion | `w_time × 0.5`, PCU 0.4 |
| Emergency | priority | `w_time × 0.2`, `w_turn = 0` |

**Vehicle restrictions are a hard constraint, not a preference.** A truck route
through a banned street is not a worse route — it is an invalid one. Model them
as **link exclusions in the routing graph**, not as penalties.

---

## 3. Time constraints / urgency

| Urgency | Behaviour |
|---|---|
| No deadline | fastest route by default weights |
| Loose (< 1.5× expected) | slight risk aversion |
| Tight (1.0–1.5×) | `w_time × 1.5`, `w_risk × 0.5` — accepts risk for time |
| Critical (< 1.0× expected) | `w_time × 2.5`, `w_risk × 0.2` |

```
urgencyFactor = expectedTime / availableTime
```

**Urgency changes risk tolerance, and it is worth saying so.** A driver late for
a hospital appointment will take a gap they would otherwise refuse. That is a real
safety mechanism and modelling it is honest, not cynical.

---

## 4. Learned history

Where the app has prior trips for a user:

```
w_time_learned = w_time × ( 1 + κ × ( habitualShare − 0.5 ) )
```

Drivers habitually over-weight routes they know. `κ = 0.3` gives a modest bias
toward the familiar route.

| Symbol | Meaning | Value |
|---|---|---|
| `κ` | habit strength | 0.3 |
| `habitualShare` | share of past trips on this route | 0–1 |

Store this **locally only**. Route history is personal data and the brief's
privacy posture should apply: it never leaves the device, and it is deletable.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance |
|---|---|---|---|
| Preference weight tables | above | ESTIMATED | stated-preference survey |
| `urgencyFactor` bands | 1.0 / 1.5 | ESTIMATED | behaviour study |
| `κ` | habit strength | 0.3 | ESTIMATED |
| VOT | value of time | 3,000 IQD/h | ESTIMATED |

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `preference` | `'fastest' \| 'shortest' \| 'safest' \| 'easiest' \| 'avoid_hills'` |
| `vehicleType` | string |
| `availableTime` | number, minutes, optional |
| `history` | local store, optional |

| Output | Type |
|---|---|
| `costWeights(ctx)` | weight object for F11 |
| `linkExclusions(ctx)` | array of forbidden road ids |
| `urgencyFactor` | number |

---

## CODE SHAPE

```
costWeights(userContext)     -> weight object
linkExclusions(vehicleType, t) -> roadId[]
urgencyFactor(expected, available) -> number
applyHabit(weights, history) -> weight object
PREFERENCE_TABLE             -> exported
VEHICLE_RESTRICTIONS         -> exported
```

**Constraint:** `costWeights` must always return the full set of weights. A
missing weight silently changes the route. Default every unspecified weight
explicitly.

---

## VALIDATION

| Test | Expectation |
|---|---|
| No context | returns the default weights unchanged |
| `'shortest'` | `w_dist` > `w_time` |
| Truck at 12:00 | centre links excluded |
| Truck at 23:00 | centre links allowed |
| Missing weight | filled with default, never `undefined` |
| `urgencyFactor(30, 30)` | returns 1.0, no division by zero |
| History absent | weights unchanged |

---

## NOTES

- **This is the file that makes the product feel personal rather than civic.**
  The same network, the same maths, a different answer for a truck driver, a
  parent doing the school run, and someone in a hurry.

- **Restrictions belong in the graph, not the cost function.** A truck sent down
  a banned street is not a modelling imprecision; it is a wrong answer. Exclude
  the link.

- **Do not persist route history to a server.** It is the only personally
  identifying data in the entire system, and the honest position is that we do
  not need it and therefore do not store it. Say that if asked — it plays well
  and it is true.
