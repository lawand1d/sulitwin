# P05 — Alternative routes

**Alternative routes → travel time comparison, toll costs, distance tradeoffs**

## PURPOSE

Produces the ranked set of route options a user is shown, and the plain-language
tradeoff between them.

This is the user-facing output of F11. The maths is there; this file defines the
*shape* of the answer.

---

## EQUATION

For each route `i`, compute and return:

```
T_i     travel time           minutes      (F13)
D_i     distance              km
F_i     toll cost             IQD          (0 in Sulaimani)
R_i     risk exposure         0–1          (F09)
N_i     turn count
ΔT_i    = T_i − T_best        minutes
ΔD_i    = D_i − D_best        km
```

Then classify the tradeoff:

```
if ΔT_i ≤ 0 and ΔD_i ≤ 0            → 'dominant'
else if ΔT_i > 0 and ΔD_i < 0       → 'slower_but_shorter'
else if ΔT_i < 0 and ΔD_i > 0       → 'faster_but_longer'
else if ΔT_i > 0 and ΔD_i > 0       → 'dominated'   (do not show)
else                                 → 'equivalent'
```

**Drop `'dominated'` routes.** Showing a route that is worse on every dimension
wastes the user's attention and implies the model cannot tell.

---

## PRESENTATION RULES

Show **at most three**. More than three is a menu, not a recommendation.

| Rank | Label | Rule |
|---|---|---|
| 1 | Fastest | lowest `T` |
| 2 | Alternative | best non-dominated route with `ΔT ≤ 5 min` |
| 3 | Scenic / avoids centre | only if it differs meaningfully |

Each option carries:

```
{ label, minutes, km, deltaMinutes, deltaKm, los, tolls, tradeoffKey, via }
```

`via` names the main streets — "via Salim Street and Bakhtiyari" is what makes a
route recognisable to someone who lives there. Extract from OSM `name` tags.

---

## TOLL COSTS

There are **no toll roads in Sulaimani**. The term stays in the equation and
returns 0.

```
tollMinutes = tollIQD / VOT_IQD_per_hour × 60
```

Keeping a term that evaluates to zero costs nothing and means the model is
reusable for a future tolled bypass or another city. **Do not delete it** —
delete it and you will have to add it back.

---

## TIME SAVINGS vs DISTANCE

The single most common user question is *"is it worth going the long way round?"*
Answer it directly:

```
breakEvenMinutes = ΔD / w_dist        where w_dist = 0.35 min/km
worthIt = ΔT_saved > breakEvenMinutes
```

Example: 2 extra km costs about 0.7 minutes of perceived effort. Saving 3 minutes
of travel time is therefore worth it. This gives the AI a defensible sentence:
*"the longer route is worth it — it saves 3 minutes for 2 extra kilometres."*

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance |
|---|---|---|---|
| `maxOptions` | routes shown | 3 | DESIGN |
| `dominanceTolerance` | minutes | 5 | DESIGN |
| `VOT` | value of time | 3,000 IQD/h | ESTIMATED |
| `w_dist` | distance weight | 0.35 min/km | ESTIMATED (F11) |

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `routes` | array from F11, each with time/distance/risk/turns |

| Output | Type |
|---|---|
| `options` | array, ranked, ≤ 3, no dominated |
| `tradeoffKey` | i18n key per option |
| `via` | string[] — named streets |

---

## CODE SHAPE

```
buildOptions(routes, preferences) -> option[]
classifyTradeoff(a, b)            -> string key
worthDetour(deltaKm, deltaMin)    -> boolean
viaStreets(route, roads)          -> string[]
```

**Constraint:** must return at least one option. If all routes are dominated —
which happens with a single viable path — return the best one with
`tradeoffKey = 'only_option'`, not an empty array.

---

## VALIDATION

| Test | Expectation |
|---|---|
| Two identical routes | both returned, neither dominated |
| One strictly worse | excluded |
| Three routes | at most 3 returned |
| Single route | returns that one, never empty |
| `worthDetour(2, 3)` | true |
| `worthDetour(10, 1)` | false |
| `via` | non-empty when routes have names |

---

## NOTES

- **Never show a route without its assumption.** Every option is computed for a
  *typical* traffic level at that time, not live conditions. The label must say
  so. An unqualified "12 minutes" implies a measurement.

- **`via` is what makes it trustworthy.** A Sulaimani resident reading "via Salim
  Street" immediately knows whether the model is serious. Street names come free
  from OSM and cost nothing to include.

- The `'only_option'` case is common in this block and is not a failure. Saying
  *"there is only one practical route"* is a useful answer, and better than
  inventing alternatives to fill a list of three.
