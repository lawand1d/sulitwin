# P01 — Vehicle classes and PCU

## PURPOSE

Converts a mixed traffic stream into a single equivalent flow in passenger car
units, so F05 and F06 can treat the road as homogeneous.

A motorcycle and a truck occupy very different amounts of road. Counting them as
one vehicle each is the most common error in simple traffic models.

---

## EQUATION

```
q_pcu = Σ_c  ( q_c × PCU_c )
```

And for capacity, the heavy-vehicle share feeds F05's `f_hv`:

```
P_hv  = Σ_{c heavy} q_c  /  Σ_all q_c
f_hv  = 1 / ( 1 + P_hv × (E_hv − 1) )
```

---

## PARAMETERS — vehicle mix

| Class | Share | PCU | Occupancy | Provenance |
|---|---|---|---|---|
| Private car | 0.55 | 1.0 | 1.4 | ESTIMATED |
| Taxi (private hire) | 0.12 | 1.0 | 1.3 | ESTIMATED |
| Shared taxi / minibus | 0.10 | 1.5 | 6.0 | ESTIMATED |
| Pickup / light goods | 0.12 | 1.5 | 1.6 | ESTIMATED |
| Truck / heavy | 0.05 | 3.0 | 1.2 | ESTIMATED |
| Motorcycle / scooter | 0.05 | 0.4 | 1.1 | ESTIMATED |
| Bicycle / cart | 0.01 | 0.5 | 1.0 | ESTIMATED |

**Shares must sum to 1.0.** Assert it at load time; a table that drifts to 1.03
silently inflates every volume in the model.

### Why these PCU values differ from the textbook

- **Minibus at 1.5, not 2.0.** It is shorter than a bus and drivers here pack
  lanes tightly. 1.5 reflects observed behaviour.
- **Motorcycle at 0.4.** Delivery scooters filter through traffic and consume far
  less road than a car, but they do disrupt lane discipline.
- **Truck at 3.0.** On the gradients that F05 models, heavy vehicles are far more
  disruptive than on the flat.

---

## Truck restrictions

Heavy vehicles are commonly banned from city centres during the day:

```
if truck AND hour in [07:00, 20:00] AND inCityCentre:
    q_truck ×= 0.25
```

Centre = within the CONFIG radius (800 m of 45.4430, 35.5571).

This is a real regulation and modelling it changes the peak-hour composition
meaningfully: the daytime stream is lighter and more homogeneous than the raw
shares suggest.

---

## INPUTS

| Input | Type |
|---|---|
| `totalFlow` | number, total vehicles/hour |
| `timeOfDay` | number |
| `inCentre` | boolean |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `q_pcu` | number | PCU-equivalent flow |
| `composition` | object | vehicles per class |
| `P_hv` | number | heavy share, for F05 |
| `vehicleCount` | number | raw vehicle count (for display) |

---

## CODE SHAPE

```
pcuFlow(totalFlow, t, inCentre)   -> { q_pcu, composition, P_hv, vehicleCount }
VEHICLE_MIX                        -> exported table
pcuOf(vehicleClass)                -> number
```

**Constraint:** `VEHICLE_MIX` shares must be normalised on load. Never trust the
table to stay summing to 1.

---

## VALIDATION

| Test | Expectation |
|---|---|
| Shares sum | 1.0 ± 1e-6 |
| `q_pcu` for pure cars | equals `totalFlow` |
| `q_pcu` for pure trucks | equals `3 × totalFlow` |
| Truck restriction at 12:00 | truck share reduced |
| Truck restriction at 23:00 | truck share unchanged |
| `P_hv` | in [0, 1] for all inputs |

---

## NOTES

- **The informal shared taxi is the local specific.** At 10% of vehicles and
  occupancy 6, it moves a meaningful share of people while behaving like a car.
  Any accessibility or equity analysis must count it as public transport even
  though it is modelled in this folder.

- If a vehicle-mix survey ever arrives, it replaces `VEHICLE_MIX` and nothing
  else. That is the entire migration.
