# Sulaimani Traffic Model — specification package

**This folder contains no code.** It is a specification an AI can convert directly
into modules. Each file maps to one code unit.

---

## The one idea that matters

> **The model is permanent. The numbers are temporary.**

Every formula in here is standard traffic engineering — BPR speed-flow, Webster
intersection delay, multinomial logit route choice, deterministic queueing. Those
do not change when real data arrives. They change *inputs*, not shape.

What is currently estimated is the **parameter set**: peak hours, demand
magnitudes, capacities, dwell times. Those are placeholder values calibrated to
what Sulaimani plausibly looks like. They are labelled `ESTIMATED` everywhere.

When the municipality supplies real counts, real signal timings, real bus
boarding data — **you replace a table of numbers and nothing else**. No formula
changes. No reasoning changes. The app gets more accurate and the explanation it
gives a citizen stays true.

That is the whole design. Build it so the numbers live in exactly one place per
factor.

---

## Folder map

```
traffic/
├── README.md                  ← you are here
├── DATA-CONTRACT.md           ← every input, and what real data replaces it
├── INTEGRATION.md             ← how the HTML app and the AI consume the model
│
├── formulas to use/           ← the mathematics (13 files, one per formula)
│   ├── README.md              ← index + dependency order
│   ├── F01 demand-profile.md
│   ├── F02 day-of-week.md
│   ├── F03 seasonal-and-ramadan.md
│   ├── F04 events.md
│   ├── F05 road-capacity.md
│   ├── F06 speed-flow.md           ★ the core equation
│   ├── F07 intersection-delay.md
│   ├── F08 weather.md
│   ├── F09 incidents.md
│   ├── F10 queue-length.md
│   ├── F11 route-choice.md
│   ├── F12 prediction.md
│   ├── F13 composite-travel-time.md ★ the master equation
│   └── F14 level-of-service.md
│
├── private/                   ← private vehicles: cars, taxis, trucks, motorcycles
│   ├── README.md
│   ├── P01 vehicle-classes-and-pcu.md
│   ├── P02 occupancy-and-vehicle-demand.md
│   ├── P03 parking-search-time.md
│   ├── P04 user-context.md
│   └── P05 alternative-routes.md
│
└── public/                    ← public transport: bus
    ├── README.md
    ├── B01 bus-network-basics.md
    ├── B02 dwell-time.md
    ├── B03 headway-and-fleet.md
    ├── B04 passenger-waiting.md
    ├── B05 bus-pcu-and-road-sharing.md
    └── B06 bus-priority.md
```

**Why `public` = bus and `private` = everything else:** they are genuinely
different systems. A private car chooses its own route and carries 1.4 people. A
bus runs a fixed route on a timetable and carries 40. They share the same
tarmac and compete for the same capacity, so they must be modelled together —
but they have different equations.

---

## Conversion order (for the AI writing the code)

Build in this order. Each step depends only on the ones above it.

```
1.  F05  capacity            no dependencies — pure lookup + arithmetic
2.  F01  demand profile      no dependencies
3.  F02  day of week         no dependencies
4.  F03  seasonal            no dependencies
5.  F04  events              no dependencies
6.  F08  weather             no dependencies
7.  F06  speed-flow          needs F01,F02,F03,F05  ← the core
8.  F07  intersection delay  needs F06
9.  F09  incidents           needs F06
10. F10  queue length        needs F06,F07
11. F14  level of service    needs F06
12. F11  route choice        needs F07,F08,F10
13. F12  prediction          needs F01 + history store
14. F13  composite           needs everything
15. P01–P05 private          needs F13
16. B01–B06 public           needs F13
```

After step 10 you have a working congestion model. Everything above that is
refinement. **If you are short on time, build 1–11 and the composite (F13) and
you have a complete, defensible traffic engine.**

---

## Honesty rules (non-negotiable, carried from the project brief)

Every value this model produces is tagged with its provenance. Three tags are
used:

| Tag | Meaning |
|---|---|
| `MEASURED` | Real observed data (traffic counts, AVL, signal logs) |
| `ESTIMATED` | Standard engineering default or locally-reasonable assumption |
| `FORECAST` | Model output derived from the above |

Until real data arrives, **everything is `ESTIMATED`**, and the UI and the AI
must both say so. The wording is fixed in `INTEGRATION.md` §4 so it cannot drift.

The model must never present a forecast as an observation. A judge or a client
who catches one fabricated number stops believing all of them.

---

## What is standard and what is local

This distinction matters when someone asks "where did you get this?"

**Standard, citable, unchanged anywhere in the world:**
- BPR volume-delay function (F06)
- Webster / HCM intersection delay (F07)
- Deterministic queueing and shockwave (F10)
- Multinomial logit route choice (F11)
- HCM level-of-service thresholds (F14)
- Transit dwell time and headway relationships (B02, B03)

**Local to Sulaimani and the Kurdistan Region — these are your calibration
targets and your competitive advantage:**
- Friday–Saturday weekend, Sunday–Thursday working week (F02)
- Thursday-evening travel peak (start of weekend) (F02)
- Ramadan iftar spike and daytime suppression (F03)
- Summer heat shifting trips to early morning and late evening (F03)
- Mountain-valley road geometry limiting real capacity (F05)
- Absence of any live traffic data source at all (DATA-CONTRACT)

Say the first list with confidence. Say the second list as *"this is our
estimate, and here is exactly what we would need to replace it."*
