# INTEGRATION — how the app and the AI consume this model

This file is the bridge. Read it after the formulas, before writing code.

---

## 1. Module boundary

The traffic model must be **pure**: no map, no DOM, no `fetch`, no `Math.random`
in the formula path. Given the same inputs it returns the same numbers.

Everything visual reads from it. Nothing visual writes to it.

### What the model exposes

| Export | Input | Output | Used by |
|---|---|---|---|
| `demandAt` | timestamp, road class | vehicles/hour for that road | F06 |
| `capacityOf` | road object | vehicles/hour | F06 |
| `speedFactor` | v/c ratio, road class | multiplier 0–1.0 | F06 |
| `travelTime` | road, timestamp, conditions | seconds | F13 |
| `levelOfService` | v/c ratio | `'A'…'F'` | UI badge, AI |
| `congestionIndex` | road, timestamp | 0–1 severity | UI colour |
| `networkAt` | timestamp | per-road results | UI + AI |
| `forecast` | timestamp, horizon | predicted congestion | AI |
| `routeOptions` | origin, destination, timestamp | ranked alternatives | AI |

### Condition object (the only mutable input)

```
conditions = {
  timestamp,          // Date or epoch ms
  weather,            // 'clear' | 'rain' | 'heavy_rain' | 'snow' | 'dust'
  incidents,          // [{ roadId, severity, since, cleared }]
  events,             // [{ name, lat, lon, radiusM, start, end, attendance }]
  closures,           // [roadId]
  userContext         // see P04 — optional, affects route choice only
}
```

---

## 2. Time is the primary input

The model is a **function of time**. This is the single biggest difference from
the current `src/traffic.js`, which animates cars at a constant speed.

```
congestion(road, t)   ← every road has a different curve
congestion(road, t+1h) ← and it changes through the day
```

The app needs a **simulated clock**:

| Control | Behaviour |
|---|---|
| Default | Real local time, snapped to the nearest 5 minutes |
| Slider | 24-hour scrub, live-updating the map |
| Day picker | Sunday…Saturday, changes F02 factors |
| Month picker | Changes F03 factors |

**The slider is the demo.** Dragging it from 03:00 to 08:00 and watching the
network load up is the moment that explains the whole model without a word.

---

## 3. How the visual layer consumes it

### 3a. Road colouring

Map `congestionIndex` to a colour ramp. Reuse the existing zone-class colours
where possible so the palette stays coherent.

| congestionIndex | LOS | Colour | Meaning |
|---|---|---|---|
| 0.00 – 0.35 | A | `#4aa08f` teal-green | free flow |
| 0.35 – 0.55 | B | `#7fa86a` | stable |
| 0.55 – 0.75 | C | `#e0973f` amber | approaching capacity |
| 0.75 – 0.90 | D | `#d97a4a` | unstable |
| 0.90 – 1.00 | E | `#c1553f` terracotta-red | at capacity |
| > 1.00 | F | `#8c2f22` dark red | breakdown |

This replaces the flat `#4a9fe0` road fill when traffic mode is on.

### 3b. Car animation

Upgrade the existing `animateTraffic` in `app.js`. Currently every car moves at
one speed. It must move at the **modelled speed for the road it is on and the
current simulated time**.

```
carSpeed(car) = freeFlowSpeed(car.road) × speedFactor(v/c for car.road, t)
```

Consequences that make it look real for free:
- cars bunch up on the busy corridor at 08:00
- side streets stay clear
- at 03:00 the whole network is nearly empty
- when you close a road, cars on the alternates visibly slow down

Add: car **density** should follow demand too, not just speed. More vehicles
spawn on high-demand roads. Density × slow speed = visible congestion.

### 3c. Car count

`adjustTrafficCount` currently spawns a fixed slider count. Scale it:

```
visibleCars(t) = BASE_CARS × demandFactor(t) / demandFactor(peak)
```

So at 03:00 you see roughly 8% of peak vehicles. This alone sells the model.

### 3d. The badge

The existing dashboard badge should read:

```
level   = levelOfService(meanCongestion(network, t))
caption = "ESTIMATED"           ← fixed wording, see §4
detail  = "08:00 weekday peak · v/c 0.82 · LOS D"
```

Never show a bare number without its timestamp and provenance.

---

## 4. Fixed wording (do not paraphrase)

These strings are part of the honesty contract. Put them in the locale files,
not inline.

| Key | English | Used when |
|---|---|---|
| `traffic.provenance` | Estimated — modelled from road class, capacity and time of day. No live traffic data exists for Sulaimani. | Always, on the badge |
| `traffic.forecast` | Forecast for {{time}} | F12 output |
| `traffic.measured` | Measured | Reserved — only when real counts load |
| `traffic.tooltip` | This is a typical-traffic model, not a live feed. | Tooltip on any red road |

**Never** use the words *real-time*, *live*, or *current traffic* anywhere in the
traffic UI until D1-style measured data is actually flowing.

---

## 5. How the AI consumes it

The assistant must receive **numbers**, not vibes, and must never invent one.

### What to pass into the prompt

```
{
  question,                     // what the user asked
  timestamp,                    // the simulated time
  dayType,                      // weekday | thursday | friday | saturday
  season,                       // normal | ramadan | summer | holiday
  weather,
  worstRoads: [                 // top 3 by congestionIndex
    { name, class, vc, los, speedKmh, provenance }
  ],
  networkMean: { vc, los, provenance },
  forecast30: { vc, los, provenance },
  activeScenarios: [...]        // e.g. a closed road
}
```

### What the AI may say

- Read any number from the payload verbatim.
- Explain *which factor* drives it: "this is the 08:00 inbound peak" (F01),
  "rain adds 18% to travel time" (F08), "it is Thursday evening" (F02).
- Compare times: "31% worse than 30 minutes from now."
- Name the mechanism: capacity, signal delay, queue, incident.

### What the AI must never do

| Never | Why |
|---|---|
| State a number not in the payload | Fabrication. The one unrecoverable error. |
| Say "right now" or "currently" | The model is typical, not live. |
| Forecast beyond 60 minutes | F12 is only calibrated to 15–30 min. |
| Give a route without its assumption | Route choice depends on F11 preferences. |
| Claim a road is clear | Absence of congestion is still an estimate. |

### Answer shape

```
1. Direct answer        — the number, with its LOS and time
2. Why                  — which factor(s) produced it
3. Provenance           — "estimated, not measured", in the same breath
4. One actionable line  — what the user could do about it
```

Point 3 is not a disclaimer bolted on the end. It is part of the answer, said
with confidence, because it is the reason the answer can be trusted at all.

---

## 6. Wiring into the existing app

| Current file | Change |
|---|---|
| `src/traffic.js` | Keep `preparePath`, `stitchRoadSegments`, `samplePathPosition`, `carRect` — they are geometry, they stay. **Add** speed and density from the model. |
| `app.js` `spawnCar` | Assign each car a road id and a class so it can look up its own speed. |
| `app.js` `animateTraffic` | Replace constant speed with `carSpeed(car)` from §3b. |
| `app.js` `updateTrafficLayer` | Read congestion for colouring. |
| `src/config.js` | Add the traffic parameter tables, or better: import them from the model files. |
| New `src/traffic-model/` | The pure model. One file per formula in `formulas to use/`. |

Keep the model in its own folder. `traffic.js` is rendering; the model is
mathematics. They should not share a file.
