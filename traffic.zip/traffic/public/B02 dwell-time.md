# B02 — Dwell time

## PURPOSE

Computes the time a bus loses at each stop. It is the single largest difference
between a bus journey and a car journey over the same road.

A bus on a 6 km corridor with 15 stops loses more time standing still than it
does in traffic.

---

## EQUATION

```
dwell = t_open + max( t_board × B , t_alight × A ) + t_close
```

| Symbol | Meaning | Value |
|---|---|---|
| `B` | boardings at this stop | passengers |
| `A` | alightings at this stop | passengers |
| `t_board` | seconds per boarding passenger | 3.0 |
| `t_alight` | seconds per alighting passenger | 2.0 |
| `t_open` | door opening | 2.0 s |
| `t_close` | door closing + pull away | 3.0 s |

Boarding and alighting happen **simultaneously** through different doors, so the
term is a maximum, not a sum. Summing them is a common error and roughly doubles
the estimate.

### The boarding penalty

Boarding is slower than alighting because of fare payment and step height:

```
t_board_effective = t_board
                  × ( 1 + 0.6 × cashShare )
                  × ( 1 + 0.4 × (loadFactor − 1) )      when loadFactor > 1
```

| Symbol | Meaning | Value |
|---|---|---|
| `cashShare` | paying cash to the driver | 0.70 |
| `loadFactor` | passengers ÷ seats | computed |

**Cash payment is why boarding is slow here.** A card system would cut
`t_board_effective` by roughly 40% and shorten every journey on the network. That
is a real, quantifiable policy result this formula produces.

---

## DWELL TIME DISTRIBUTION

Use a **floor and a tail**, not a constant:

```
dwell_final = max( 5,  dwell + noise )
noise ~ Normal(0, 1.5)     ← seeded RNG only
```

A bus never leaves in under 5 seconds however empty it is.

---

## MISCELLANEOUS DELAYS

Add on top, per trip:

| Cause | Expected loss |
|---|---|
| Traffic signal not prioritised | 12 s per signal |
| Unable to re-enter traffic from stop | 6 s per stop |
| Passenger with luggage / wheelchair | +20 s when it occurs |
| Driver break | excluded — belongs to B03 |

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `t_board` | per boarding | 3.0 s | ESTIMATED | APC + AVL data |
| `t_alight` | per alighting | 2.0 s | ESTIMATED | APC + AVL |
| `t_open` / `t_close` | door cycle | 2.0 / 3.0 s | ESTIMATED | observation |
| `cashShare` | cash payment share | 0.70 | ESTIMATED | operator data |
| `minDwell` | floor | 5.0 s | STANDARD | — |

**How to measure:** transit agencies the world over compute exactly this from
automatic vehicle location data. If Sulaimani's operator has AVL, one month of
data sets every number in this table.

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `boardings`, `alightings` | number, at this stop |
| `loadFactor` | number |
| `cashShare` | number, optional |
| `rng` | seeded RNG |

| Output | Type |
|---|---|
| `dwellSeconds(...)` | number |
| `tripDwellSeconds(route)` | number — sum over all stops |
| `dwellShare(tripDwell, tripTotal)` | number — fraction of journey lost |

`dwellShare` is the number to show a planner. On a short urban route it is
commonly 20–30%, and seeing that figure is what makes people take bus priority
seriously.

---

## CODE SHAPE

```
dwellSeconds(boardings, alightings, ctx) -> number
tripDwellSeconds(route, demand, rng)     -> number
boardingPenalty(cashShare, loadFactor)   -> number  multiplier
DWELL_PARAMS                             -> exported
```

**Constraint:** must be ≥ `minDwell` always, and must use the **injected seeded
RNG**, never `Math.random()`. Dwell variability makes the demo non-repeatable
otherwise.

---

## VALIDATION

| Test | Expectation |
|---|---|
| No passengers | exactly `minDwell` (approx 5 s) |
| 10 board, 5 alight | ~32 s |
| 5 board, 10 alight | ~25 s |
| Both double | less than double the time (max, not sum) |
| `cashShare = 0` | boarding penalty disappears |
| `loadFactor = 2` | dwell longer than at `loadFactor = 1` |
| Same seed | identical output |

---

## NOTES

- **Dwell is the bus's tax for being useful.** Every passenger who boards is the
  reason the bus exists and also the reason it is slow. Any model that treats
  buses as "cars that hold more people" will underestimate their delay by a wide
  margin and will therefore recommend the wrong policies.

- **The cash-payment result is the best output in this folder.** It converts a
  fare-collection policy question into a travel-time answer, which is exactly the
  kind of link between policy and consequence the product is supposed to make.

- Bus stops are already in the data (39 in the demo block). Use them. A dwell
  model attached to real stop locations is immediately credible.
