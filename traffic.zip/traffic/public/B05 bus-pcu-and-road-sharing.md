# B05 — Bus equivalents and road sharing ★

**The file that justifies the whole `public/` folder.**

## PURPOSE

Converts between buses and cars on a shared road, and produces the **person-
throughput comparison** that decides whether a bus lane, a bus gate, or a bus
priority scheme is worth it.

Every other file in this folder exists to feed this one.

---

## THE COMPARISON

```
personThroughput(link) = Σ_c ( vehiclesPerHour_c × occupancy_c )
```

| Mode | Vehicles/h | Occupancy | **Persons/h** | Road space used |
|---|---|---|---|---|
| Cars | 1,800 | 1.4 | **2,520** | 100% |
| Buses | 40 | 40 | **1,600** | 100% |
| Cars + buses mixed | 1,750 + 40 | — | ~4,000 | 100% |
| **Bus lane: 1 lane buses, 3 lanes cars** | 30 + 4,500 | — | **1,200 + 6,300 = 7,500** | 100% |

**Read that last row again.** Removing one lane from cars to give it to buses
*increases* total person throughput, even when buses carry only 40 people each
and run at moderate frequency.

That is the argument, and this formula is what produces it.

---

## EQUATION

### Bus equivalents in traffic (PCU)

A bus occupies more road than a car, and more again when it is stopping:

```
PCU_bus = 2.0                           moving
        = 2.5 + 0.5 × (boardings/10)    at a stop with passengers
```

A stationary bus at a stop can block a lane entirely on a narrow street. Model
this explicitly — it is why bus stops must be set back from junctions (B01).

### Capacity consumed by a bus stop

```
C_lost = busFrequency × dwellSeconds / 3600 × C_lane
```

A stop served every 5 minutes with 30-second dwells removes roughly 10% of a
lane's capacity even when no bus is present, because approaching buses slow and
vehicles change lanes around them.

### Person delay (the decisive output)

```
personDelay_car = Σ ( carDelaySeconds × carFlow × occupancy_car )
personDelay_bus = Σ ( busDelaySeconds × busFlow × occupancy_bus )
```

### The priority test

```
if personDelay_saved_bus > personDelay_added_car  →  the intervention pays
```

Report both numbers. **Never report only the car delay** — that is the error that
has kept buses slow in every city that made it.

---

## COLUMN SPACE EQUIVALENCE

A frequently quoted and useful presentation figure:

```
roadSpacePerPerson_bus  = roadWidth / personsPerHour_bus
roadSpacePerPerson_car  = roadWidth / personsPerHour_car
```

At 40 passengers per bus and 1.4 per car, a bus uses roughly **1/28th** the road
space per person moved. That single ratio is often the most persuasive number in
an entire transport presentation.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `PCU_bus` | moving bus equivalent | 2.0 | STANDARD | — |
| `PCU_bus_stopped` | at-stop equivalent | 2.5–3.0 | ESTIMATED | observation |
| `occupancy_bus` | passengers per bus | 40 | ESTIMATED | APC data |
| `occupancy_car` | persons per car | 1.4 | ESTIMATED | P02 |
| `carLaneCapacity` | per lane | 1,800 veh/h | ESTIMATED | F05 |
| `busLaneCapacity` | buses per lane | 90 veh/h | ESTIMATED | ~40 s headway minimum |

**`occupancy_bus = 40` is the number the whole conclusion rests on.** It is also
the easiest to measure — one week of automatic passenger counts settles it. Flag
it as the priority data acquisition for this folder.

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `carFlow`, `busFlow` | veh/h |
| `carDelay`, `busDelay` | seconds |
| `dwellSeconds`, `busFrequency` | for stop capacity loss |

| Output | Type |
|---|---|
| `personsPerHour(mode)` | number |
| `pcuBus(moving, boardings)` | number |
| `stopCapacityLoss(frequency, dwell)` | number |
| `personDelayComparison(...)` | `{ carPersonHours, busPersonHours, verdict }` |
| `roadSpacePerPerson(mode)` | number, m² |

---

## CODE SHAPE

```
personThroughput(flow, occupancy)      -> number
pcuBus(moving, boardings)              -> number
stopCapacityLoss(freq, dwell, cLane)   -> number
comparePersonDelay(car, bus)           -> { carPersonHours, busPersonHours, saved, verdict }
roadSpacePerPerson(flow, occupancy, width) -> number
```

**Constraint:** `comparePersonDelay` must return **both** sides always. A function
that can return only the car side is a function that will eventually be misused.

---

## VALIDATION

| Test | Expectation |
|---|---|
| 1,800 cars at 1.4 | 2,520 persons/h |
| 40 buses at 40 | 1,600 persons/h |
| `pcuBus(moving)` | exactly 2.0 |
| `pcuBus` at stop with 20 boardings | > 2.5 |
| Bus lane scenario | total persons/h increases |
| `roadSpacePerPerson` bus vs car | ratio ≈ 1/25 to 1/30 |
| Zero bus flow | returns the car side only, no division by zero |

---

## NOTES

- **This is the most politically important formula in the entire model.** It is
  the arithmetic behind every bus lane, every bus gate, and every congestion
  charge ever implemented. Producing it correctly — and showing both sides — is
  what distinguishes a planning tool from a traffic counter.

- **Show both numbers, always, in that order: cost to cars first, benefit to
  people second.** Leading with the benefit looks like advocacy. Leading with the
  cost, then showing it is outweighed, looks like analysis. Same numbers,
  completely different reception.

- **The honest caveat:** this comparison uses *modelled* occupancies. If
  `occupancy_bus` is wrong by half, the conclusion can flip. Say the number, say
  it is estimated, say what would settle it. That is exactly the posture the rest
  of the product takes, and here it matters most.

- **The demo:** drag the clock to 08:00, note the car person-hours. Now add a bus
  lane on Salim Street. Cars get slower and the car number worsens — then the bus
  number improves by more. **That reversal, shown live, is the single strongest
  moment this model can produce.**
