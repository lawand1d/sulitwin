# B04 — Passenger waiting and crowding

## PURPOSE

Converts service frequency and reliability into the time passengers actually
lose, and into how full the buses are.

Waiting is usually the largest single component of a bus passenger's journey —
larger than the in-vehicle time on a short urban trip.

---

## EQUATION

### Average wait — random arrivals

```
E[wait] = headway / 2
```

Valid when headway ≤ 12 minutes. A passenger who does not consult a timetable
arrives at random and waits, on average, half a headway.

### Average wait — planned arrivals

For longer headways, passengers time their arrival:

```
E[wait] = headway / 2 × planningFactor
planningFactor = 0.5      for headway > 15 min
```

People do not perfectly time arrivals; they build in a margin. Halving again is
the standard approximation.

### Excess wait from unreliability

**This is the term most models omit and it is the one passengers feel.**

```
E[excess] = 0.5 × ( σ_headway² / headway )
```

| Symbol | Meaning |
|---|---|
| `σ_headway` | standard deviation of actual headways |

Unreliable services hurt **disproportionately**: because of the squared term,
doubling the variability quadruples the excess wait. This is also what causes
**bus bunching** — a late bus picks up more passengers, gets later, and the bus
behind catches up.

### Crowding multiplier

Passengers value time standing more than sitting, and more still when crushed:

```
crowdFactor = 1.0                                    loadFactor ≤ 0.8
            = 1.0 + 0.35 × (loadFactor − 0.8)       0.8 < loadFactor ≤ 1.0
            = 1.07 + 1.20 × (loadFactor − 1.0)      loadFactor > 1.0
```

```
effectiveTime = ( inVehicleTime + walkTime ) × crowdFactor + waitTime
```

### Load factor

```
loadFactor = passengersOnBoard / seatedCapacity
```

| loadFactor | Condition |
|---|---|
| < 0.8 | comfortable, seat available |
| 0.8 – 1.0 | full, seats taken |
| 1.0 – 1.3 | standing, acceptable |
| > 1.3 | crush — passengers left behind |

---

## WHY THIS IS THE EQUITY FILE

A car occupant's journey time is roughly constant regardless of how many other
people choose to drive. **A bus passenger's journey time depends on how many
other people are on the bus.** That asymmetry is the entire case for prioritising
buses, and it is only visible if waiting and crowding are modelled.

A model without B04 will systematically under-value public transport.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `planningFactor` | timed-arrival factor | 0.5 | STANDARD | — |
| `waitThreshold` | headway for planning | 15 min | STANDARD | — |
| `σ_headway` | headway variability | **120 s** | ESTIMATED | AVL data |
| `crowdFactor` | crowding weights | above | STANDARD (TRL/DfT values) | local survey |
| `seatedCapacity` | seats | 40 | ESTIMATED | vehicle spec |
| `crushCapacity` | max standing | 70 | ESTIMATED | vehicle spec |
| `walkSpeed` | walking speed | 1.2 m/s | STANDARD | — |

The crowding multipliers follow the widely-used UK Department for Transport
values. They are standard and citable.

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `headwaySeconds` | number |
| `sigmaHeadway` | number, optional |
| `loadFactor` | number |
| `inVehicleSeconds`, `walkMetres` | number |

| Output | Type |
|---|---|
| `averageWait(headway, planning)` | number |
| `excessWait(headway, sigma)` | number |
| `crowdFactor(loadFactor)` | number |
| `generalisedJourneyTime(...)` | number — the comparable figure |

`generalisedJourneyTime` is what allows a fair comparison with a car. Without it,
any car-versus-bus comparison is rigged.

---

## CODE SHAPE

```
averageWait(headwaySeconds, planned)  -> number
excessWait(headwaySeconds, sigma)     -> number
crowdFactor(loadFactor)               -> number
loadFactor(onBoard, seatedCapacity)   -> number
generalisedJourneyTime(journey)       -> number
CROWD_PARAMS                          -> exported
```

**Constraint:** `generalisedJourneyTime` must be comparable to a car's travel
time — same units, same value-of-time basis. If the two are not comparable, the
B05 comparison is meaningless.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `averageWait(600, false)` | exactly 300 s |
| `averageWait(1800, true)` | 450 s |
| `excessWait` with σ = 0 | exactly 0 |
| σ doubled | excess wait ×4 (the squared term) |
| `loadFactor = 0.5` | crowdFactor exactly 1.0 |
| `loadFactor = 1.5` | crowdFactor > 1.6 |
| Empty bus | no crowding penalty |

---

## NOTES

- **Waiting time is felt more than in-vehicle time.** A common planning convention
  weights waiting at 1.5–2× in-vehicle time. It is not applied in the default
  formula above — keep it as an optional weight and state whether it is active,
  because it substantially changes conclusions about service frequency.

- **The squared variability term is the most valuable line in this file.** It is
  the mathematical reason unreliability is so damaging, and it justifies spending
  on recovery time (B03) rather than only on more buses.

- **Bus bunching is the visible symptom.** If the model shows very high
  `σ_headway`, the AI can say *"this service is at risk of bunching"* — which is a
  diagnosis a transit planner recognises instantly and a strong sign the model is
  real rather than decorative.
