# public/ — public transport (bus)

**Everything that runs to a timetable on a fixed route.** In Sulaimani that is
the bus network, plus the formally-registered minibus lines.

---

## What "public" means here

1. **Fixed route.** Cannot detour around a closure. A blocked road is a blocked
   bus.
2. **Fixed schedule.** Departure times are decided in advance, not by traffic.
3. **Stops.** It must stop, dwell, and re-enter traffic — repeatedly.
4. **Many people per vehicle.** ~40, versus ~1.4 for a car. This is the entire
   reason it matters.
5. **It anchors equity.** The people who depend on it are the people with the
   least alternative. A model that only counts cars systematically ignores them.

---

## Why this folder exists separately

Two decisions look identical if you only model cars, and opposite if you model
buses:

| Decision | Effect on cars | Effect on bus passengers |
|---|---|---|
| Close a road | Re-route, minor delay | Route broken, service cancelled |
| Add a bus lane | One lane removed — cars slower | Hundreds of people faster |
| Build a bypass | Everyone faster | Bus unchanged unless re-routed |

**The bus lane is the decisive one.** Taken on car delay alone, a bus lane always
loses. Counted per person, it usually wins by an order of magnitude. A model that
cannot show that has no business advising a city.

That comparison — **delay per person, not per vehicle** — is the single most
valuable output of this folder.

---

## Files

| File | Covers |
|---|---|
| [B01](B01%20bus-network-basics.md) | Routes, stops, the network graph, OSM route relations |
| [B02](B02%20dwell-time.md) | Time lost at each stop |
| [B03](B03%20headway-and-fleet.md) | Timetable, cycle time, how many buses are needed |
| [B04](B04%20passenger-waiting.md) | Waiting time, crowding, reliability |
| [B05](B05%20bus-pcu-and-road-sharing.md) | Bus equivalents in traffic, and the person-throughput comparison |
| [B06](B06%20bus-priority.md) | Bus lanes and signal priority — the model that justifies them |

---

## The local reality

Sulaimani's public transport is **predominantly informal**: shared taxis and
minibuses running semi-fixed corridors, plus a formal bus network that is thin.

Consequences for the model:

- OSM `route=bus` relations may be **sparse or absent**. Query Overpass for the
  demo block and commit whatever exists; do not assume coverage.
- Where no formal route data exists, **model a candidate network** and label it
  clearly as a proposal. "If a bus ran this corridor every 10 minutes, here is
  what it would carry" is a more useful output for a planner than an empty map.
- The many-to-many comparison in B05 is what makes this folder worth building
  even with imperfect route data.

---

## The output that matters

For any corridor, report:

```
personDelay_car  = Σ (car delay × car occupancy)
personDelay_bus  = Σ (bus delay × bus occupancy)
```

Then compare. Every other number in this folder exists to produce those two.
