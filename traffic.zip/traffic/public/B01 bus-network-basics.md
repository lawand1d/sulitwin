# B01 — Bus network basics

## PURPOSE

Builds the bus network from OSM data: routes, stops, and the ordered stop
sequence a bus actually serves. Everything else in `public/` depends on this
structure existing.

---

## THE MODEL OBJECT

```
route = {
  id, ref, name,
  stops: [ stopId ... ],        ordered
  path:  [ [lon,lat] ... ],     road geometry between stops
  legLengths: [ metres ],       stop i → stop i+1
  direction: 'outbound' | 'inbound',
  headwaySec,                   from B03
  fleetSize                     from B03
}

stop = {
  id, name, coord,
  boardings, alightings,        per hour, from B04
  shelter: boolean,
  routes: [ routeId ... ]
}
```

---

## BUILDING IT FROM OSM

| Element | OSM source |
|---|---|
| Route | relation with `type=route`, `route=bus` |
| Stop sequence | relation members of `role=stop` / `platform`, **in member order** |
| Stop location | member node, or the platform way's centroid |
| Route geometry | the ways in the relation, in order, stitched |
| Route name | `ref` and `name` tags |

**Member order is the stop sequence.** Do not sort by distance or geometry — the
relation order is the authoritative order and re-sorting breaks loop routes.

### Stitching geometry

Reuse the existing `stitchRoadSegments` in `src/traffic.js`. It already joins
segments sharing endpoints. Match on the 5-decimal coordinate key it uses.

---

## WHAT TO DO WHEN OSM HAS NOTHING

Very likely for Sulaimani: formal `route=bus` relations may be absent or sparse.

**Do not leave the folder empty.** Fall back to a **proposed network**:

1. Find the highest-capacity corridors in the road graph (use F05 capacity)
2. Place stops every **400 m** along them
3. Link them into 2–4 candidate lines crossing the demo block
4. Label every output `PROPOSED`, never `EXISTING`

A proposed network is more useful to a planner than an empty map, and it powers
the B05 comparison, which is the reason this folder exists.

> The honest framing: *"there is no complete digital record of Sulaimani's bus
> network. Rather than show you an empty layer, we modelled what a service on
> these corridors would carry. Here is the assumption."*

---

## STOP PLACEMENT RULES

For a proposed network:

| Rule | Value | Reason |
|---|---|---|
| Spacing | 350–450 m | walking catchment |
| Max walk to a stop | 400 m (5 min) | standard transit planning |
| Place at junctions | preferred | access from both streets |
| Avoid within 50 m of a junction | required | buses must not block the stop line |
| Near demand | POI + building density | from the existing POI data |

The existing bus stop data (39 stops in the demo block, already fetched) gives
real anchor points. **Use them where they exist** and fill gaps with proposals,
clearly tagged.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `stopSpacing` | proposed spacing | 400 m | STANDARD | transit planning practice |
| `maxWalk` | catchment radius | 400 m | STANDARD | — |
| `minJunctionClearance` | from stop line | 50 m | STANDARD | — |
| `routeSet` | the network | OSM or proposed | `OSM` / `PROPOSED` | operator data |

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `osmRelations` | route relations, possibly empty |
| `roads` | for proposal generation |
| `existingStops` | the 39 known stops |

| Output | Type |
|---|---|
| `routes` | route[] |
| `stops` | stop[] |
| `networkSource` | `'OSM' \| 'PROPOSED' \| 'MIXED'` |

`networkSource` **must** propagate to the UI and to the AI. Every downstream
claim inherits it.

---

## CODE SHAPE

```
buildNetwork(osmRelations, roads, existingStops) -> { routes, stops, networkSource }
stitchRouteGeometry(ways)                        -> coords
proposeNetwork(roads, existingStops)             -> { routes, stops }
stopsAlongCorridor(road, spacing)                -> stop[]
```

**Constraint:** every returned route must have ≥ 2 stops and ≥ 2 path
coordinates, or be dropped. A one-stop route is a data error, not a service.

---

## VALIDATION

| Test | Expectation |
|---|---|
| Empty OSM input | returns a `PROPOSED` network with ≥ 2 routes |
| Any route | ≥ 2 stops |
| Stop spacing | 300 – 500 m on proposed routes |
| Stop sequence | preserved from relation member order |
| Loop route | first and last stop may coincide without error |
| `networkSource` | never `undefined` |
| Route geometry | continuous, no gaps > 100 m between consecutive points |

---

## NOTES

- **Never present a proposed network as an existing one.** This is the sharpest
  honesty risk in the whole traffic folder — a plausible-looking bus map is
  easily mistaken for a real one. Tag it in the data, the UI and the AI prompt.

- The 39 existing stops are real and should anchor the proposal. Mixed
  real/proposed networks are fine as long as each stop carries its own flag.

- Route `ref` (the number on the front of the bus) matters more than `name` for
  recognition. Prefer `ref` when both exist.
