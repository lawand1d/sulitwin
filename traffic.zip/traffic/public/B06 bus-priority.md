# B06 — Bus priority

## PURPOSE

Models the interventions that make buses faster: bus lanes, signal priority, queue
jumps, and bus gates. Produces the travel-time and person-delay consequences of
each.

This is where the model stops describing and starts **recommending**.

---

## THE FOUR INTERVENTIONS

| Intervention | Mechanism | Typical gain | Cost |
|---|---|---|---|
| **Bus lane** | dedicated road space | 15–35% journey time | one car lane |
| **Signal priority** | green extended / early | 8–15% | minor car delay |
| **Queue jump** | bus advances at signals | 5–12% | junction redesign |
| **Bus gate** | cars banned from a link | 20–40% | cars re-route |

---

## EQUATION

### Bus lane

A bus lane removes the bus from the general traffic stream:

```
v_bus_lane = v0 × 0.95                       ← near free-flow, no car interference
v_car_general = F06( q_cars , C − C_bus_lane )
```

Cars lose a lane; buses gain a clear one.

```
C_car_new = C_total × (lanes − 1) / lanes
```

Do **not** set the bus lane's car capacity to zero and divide by it — exclude the
lane from the car calculation entirely. This is a structural change to the link,
not a parameter change.

### Signal priority

```
d_bus_signal = d_intersection × ( 1 − priorityEffect )
priorityEffect = 0.60     active green extension
               = 0.25     passive (offset tuning only)
```

Cars pay a small cost:

```
d_car_signal = d_intersection × ( 1 + carPenalty )
carPenalty = 0.03         for a low-frequency service
           = 0.08         for a high-frequency service
```

### Queue jump

```
d_bus_queuejump = min( d_queue , 15 s )      ← caps the benefit
```

A queue jump helps only until the bus clears the junction; beyond that it confers
nothing. Capping it prevents the model from promising unlimited gains.

### Bus gate

```
if busGate AND vehicle != bus:
    link excluded from the car routing graph      ← a P04-style hard exclusion
```

---

## THE DECISION RULE

Apply B05's comparison:

```
benefit  = personDelay_saved_bus   × occupancy_bus
cost     = personDelay_added_car   × occupancy_car

recommend  if  benefit > cost × (1 + margin)      margin = 0.20
```

The 20% margin exists so the model does not recommend interventions that are
marginal in the model and will be lost to noise in reality. **Recommend only when
the case is clear.** A tool that recommends everything is not giving advice.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `busLaneSpeedFactor` | bus free-flow on own lane | 0.95 | ESTIMATED | before/after study |
| `priorityEffect` | active | 0.60 | ESTIMATED | before/after study |
| `priorityEffect` | passive | 0.25 | ESTIMATED | before/after |
| `carPenalty` | low freq | 0.03 | ESTIMATED | before/after |
| `carPenalty` | high freq | 0.08 | ESTIMATED | before/after |
| `queueJumpCap` | maximum benefit | 15 s | ESTIMATED | observation |
| `margin` | recommendation margin | 0.20 | DESIGN | — |
| `minBusFrequency` | to justify a lane | 6 buses/h | STANDARD | transit practice |

**Before/after studies are the real source for every number here**, and they are
the standard way these figures are established anywhere in the world. If a
Sulaimani bus lane is ever built, measuring it before and after replaces this
entire table.

---

## MINIMUM VIABILITY

Do not recommend a bus lane below a frequency that can use it:

```
if busFrequency < minBusFrequency (6/h, i.e. 10-minute headway):
    → recommend signal priority instead, not a lane
```

An empty bus lane is worse than no bus lane: it removes car capacity and delivers
nothing. This check is what separates a model that understands transit from one
that has read about it.

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `link` | road object |
| `busFlow` | veh/h |
| `intervention` | `'bus_lane' \| 'signal_priority' \| 'queue_jump' \| 'bus_gate'` |
| `conditions` | from F13 |

| Output | Type |
|---|---|
| `applyIntervention(link, intervention)` | modified link |
| `evaluateIntervention(link, intervention)` | `{ busGain, carCost, verdict }` |
| `recommend(link)` | intervention \| null |

---

## CODE SHAPE

```
applyIntervention(link, kind)         -> modified link
evaluateIntervention(link, kind, ctx) -> { busSecondsSaved, carSecondsAdded,
                                           personBenefit, personCost, verdict }
recommend(link, ctx)                  -> kind | null
minimumViableFrequency()              -> number
PRIORITY_PARAMS                       -> exported
```

**Constraint:** `applyIntervention` must return a **new** link object. Mutating
the input corrupts the baseline and makes before/after comparison impossible —
which is the entire point of the function.

---

## VALIDATION

| Test | Expectation |
|---|---|
| Bus lane | bus travel time strictly decreases |
| Bus lane | car travel time strictly increases |
| Bus lane | total person delay decreases *when bus flow is sufficient* |
| Signal priority | bus delay falls, car delay rises slightly |
| Queue jump | benefit capped at 15 s |
| Bus gate | non-bus routes avoid the link |
| Low frequency (< 6/h) | `recommend` returns signal priority, not a lane |
| `applyIntervention` | original link unmodified |
| No intervention | `verdict = 'no_change'`, both numbers zero |

---

## NOTES

- **Never recommend a bus lane on a corridor with almost no buses.** The model
  must actively refuse. That refusal is a feature and it is worth demonstrating:
  it shows the tool has judgement rather than a bias.

- **The bus gate is the one that changes the map visibly**, because cars must find
  another route. That re-routing flows through F11 and can produce the most
  interesting second-order effects in the whole model — including making some
  other street worse. Show that consequence; do not hide it.

- **This file is where the model becomes advisory**, and advisory models get
  challenged. Every recommendation must be able to state the number it rests on,
  its provenance, and what would change the answer. Build `evaluateIntervention`
  to return all three, and have the AI read them out.

- The strongest single demo in this folder: apply a bus lane on Salim Street,
  watch the car number get worse and the person number get better, and let the
  model say — in Sorani — *"cars are slower, but more people are moving."*
