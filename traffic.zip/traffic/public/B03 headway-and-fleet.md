# B03 — Headway and fleet

## PURPOSE

Connects the timetable to the number of buses needed and to how long a passenger
waits. This is the economics of the service — the formula that decides whether a
proposed route is affordable.

---

## EQUATION

### Cycle time

```
T_cycle = 2 × ( T_running + T_dwell_total + T_turnaround )
```

The factor of 2 is the return journey. `T_turnaround` is recovery time at each
end — **do not omit it.** Without recovery a bus is late for the rest of the day
and the timetable collapses.

### Fleet size

```
N_buses = ceil( T_cycle / headway )
```

### Headway from a fleet

```
headway = T_cycle / N_buses
```

### Service frequency

```
busesPerHour = 3600 / headway_seconds
```

---

## THE RELATIONSHIP THAT MATTERS

```
shorter headway  →  more buses  →  higher cost  →  but shorter waits
```

Every transit decision is a point on this curve. The model's job is to show the
tradeoff, not to pick a point.

| Headway | Buses needed (T_cycle = 60 min) | Wait (random arrival) | Frequency |
|---|---|---|---|
| 30 min | 2 | 15 min | 2/h |
| 20 min | 3 | 10 min | 3/h |
| 15 min | 4 | 7.5 min | 4/h |
| **10 min** | **6** | **5 min** | **6/h** |
| 5 min | 12 | 2.5 min | 12/h |

**10 minutes is the usual threshold** below which a service stops needing a
timetable — passengers just turn up. That is the standard a proposed network
should be judged against.

---

## TURNAROUND / RECOVERY

```
T_turnaround = max( 3 min,  0.12 × T_running_one_way )
```

Recovery absorbs variability. If reliability is poor (B04), recovery must be
larger — this is where unreliability becomes a cost rather than an annoyance.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `turnaroundMin` | minimum recovery | 3 min | STANDARD | operator practice |
| `turnaroundFrac` | recovery fraction | 0.12 | STANDARD | operator practice |
| `targetHeadway` | design headway | **600 s** | DESIGN | policy choice |
| `serviceHours` | operating window | 06:00 – 23:00 | ESTIMATED | operator timetable |
| `busCapacity` | seated + standing | 70 | ESTIMATED | vehicle spec |
| `seatedCapacity` | seats | 40 | ESTIMATED | vehicle spec |

---

## INPUTS / OUTPUTS

| Input | Type |
|---|---|
| `runningSeconds` | number, one-way, from F13 |
| `dwellTotal` | number, from B02 |
| `headway` or `fleetSize` | one of the two |

| Output | Type |
|---|---|
| `cycleSeconds` | number |
| `fleetSize` | number, integer |
| `headwaySeconds` | number |
| `busesPerHour` | number |
| `dailyBusKm` | number — the cost driver |

`dailyBusKm` is what an operator actually budgets against. Producing it makes the
model useful to the operator, not only to the planner.

---

## CODE SHAPE

```
cycleTime(runningOneWay, dwellTotal)  -> number
fleetFor(cycleSeconds, headway)       -> number
headwayFor(cycleSeconds, fleet)       -> number
serviceSummary(route, demand)         -> { cycleSeconds, fleet, headway, busesPerHour, dailyBusKm }
TARGET_HEADWAY                        -> exported
```

**Constraint:** `fleetFor` must return an integer ≥ 1. A fractional bus does not
exist, and rounding down would produce a headway the fleet cannot deliver.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `fleetFor(3600, 600)` | exactly 6 |
| `fleetFor(3600, 700)` | 6 (ceiling, not floor) |
| `headwayFor(3600, 6)` | 600 s |
| One-way time doubled | cycle time doubles |
| `fleetSize` | always integer ≥ 1 |
| `dailyBusKm` | positive, scales with frequency |

---

## NOTES

- **Recovery time is the honest part.** Operators who skip it run unreliable
  services and then wonder why. Modelling recovery explicitly makes the cost of
  reliability visible, which is a real planning insight rather than a detail.

- **Bus running time comes from the same F13 as cars** — but see B05: a bus is
  delayed more by dwell and re-entry, and less if it has priority. The two must
  share the congestion model or the comparison between them is meaningless.

- This is the file that answers *"can we afford it?"* Every proposal should come
  with its `fleetSize` and `dailyBusKm` attached. An unfunded proposal is not a
  proposal.
