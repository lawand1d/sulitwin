# F13 — Composite travel time ★

**The master equation.** Every other formula plugs in here.

## PURPOSE

Takes a road, a time, and a set of conditions, and returns the actual travel time,
delay, speed and level of service.

This is the only function the app and the AI need to call for the common case.
Everything else exists to feed it.

---

## THE FULL PIPELINE

Order matters. Apply top to bottom.

```
┌─ 1. DEMAND ────────────────────────────────────────────────────┐
│  q_base   = baseline flow for this road (veh/h)                │
│  q        = q_base                                             │
│             × D(t)          ← F01  time of day                 │
│             × W(d)          ← F02  day of week                 │
│             × S(date)       ← F03  season / Ramadan            │
│             + Δq_event       ← F04  events (ADDITIVE)          │
│  q        = max(q, q_min)                                      │
└────────────────────────────────────────────────────────────────┘
                              │
┌─ 2. CAPACITY ──────────────────────────────────────────────────┐
│  C_road   = N × 1900 × fw × fhv × fterrain × fside   ← F05     │
│  C_eff    = C_road                                             │
│             × f_weather_cap   ← F08                            │
│             × f_incident      ← F09                            │
│             × ( isClosed ? 0 : 1 )   ← conditions.closures     │
│  C_eff    = max(C_eff, C_FLOOR)                                │
└────────────────────────────────────────────────────────────────┘
                              │
┌─ 3. SATURATION ────────────────────────────────────────────────┐
│  x = q / C_eff                    ← volume / capacity ratio    │
└────────────────────────────────────────────────────────────────┘
                              │
┌─ 4. SPEED ─────────────────────────────────────────────────────┐
│  v0_eff   = v0                                                 │
│             × f_weather_speed   ← F08                          │
│             × (1 − 0.35·sin θ)  ← terrain, from DEM            │
│  v        = v0_eff × speedFactor(x)     ← F06  BPR             │
│  v        = max(v, v_FLOOR)                                    │
└────────────────────────────────────────────────────────────────┘
                              │
┌─ 5. TIMES ─────────────────────────────────────────────────────┐
│  t_link   = length / v                                         │
│  d_int    = intersectionDelay(X, ...)   ← F07                  │
│  d_queue  = queueDelay(L, C_eff, q)     ← F10                  │
│  t_total  = t_link + d_int + d_queue                           │
│  t_free   = length / v0_eff                                    │
│  delay    = t_total − t_free                                   │
└────────────────────────────────────────────────────────────────┘
                              │
┌─ 6. GRADE ─────────────────────────────────────────────────────┐
│  LOS      = levelOfService(x)           ← F14                  │
│  congIdx  = congestionIndex(x)          ← for UI colouring     │
└────────────────────────────────────────────────────────────────┘
```

---

## EQUATION, condensed

```
q       = q_base · D(t) · W(d) · S(date) + Σ Δq_event
C_eff   = C_road · f_weather · f_incident · f_closure
x       = q / C_eff
v       = v₀ · f_weather · f_terrain · [ 1 / (1 + α·x^β) ]
t_total = L/v + d_intersection + d_queue
delay   = t_total − L/v₀
```

---

## ROUTE-LEVEL AGGREGATION

```
T_route = Σ t_total over all links in the route
D_route = Σ delay
LOS_route = weighted mean of link LOS, weighted by link travel time
```

**Do not take the worst link as the route's LOS.** A route with one bad junction
is not a bad route. Weighting by time is the correct aggregation and prevents the
model from flagging a mostly-free-flowing route as failing.

---

## NETWORK-LEVEL AGGREGATION

For the dashboard badge:

```
networkCongestion = Σ (q_i · delay_i)  /  Σ (q_i · t_free_i)
```

This is **delay-weighted**, not a simple average. A quiet side street being slow
should not move a city-wide indicator. Weighting by vehicles affected is what
makes the badge mean something.

Also report:

```
vehicleHoursLost = Σ ( delay_i · q_i ) / 3600        per hour
```

**That is the number to show a decision-maker.** "Closing this road costs 127
vehicle-hours a day" is an argument. "Congestion index 0.82" is not.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance |
|---|---|---|---|
| `q_min` | minimum demand floor | 5 veh/h | ESTIMATED |
| `C_FLOOR` | minimum capacity | 150 veh/h | ESTIMATED |
| `v_FLOOR` | minimum speed | 4 km/h | ESTIMATED |
| `q_base` | baseline flow | **derived, see below** | ESTIMATED |

### Deriving `q_base`

We do not have counts, so baseline flow must be estimated from the network itself:

```
q_base(road) = C_road × BASELINE_LOAD[highway]

BASELINE_LOAD = {
  motorway: 0.55, trunk: 0.52, primary: 0.50, secondary: 0.42,
  tertiary: 0.35, residential: 0.22, service: 0.15, default: 0.25
}
```

This says: a primary road runs at about half its capacity on an average day. That
is a defensible planning assumption and it is **the single largest source of
uncertainty in the entire model.**

Say so. Do not bury it. If asked "how do you know the traffic volumes?", the
honest answer is: *"we don't. We estimate that a primary road runs at about half
its capacity, which is a standard planning assumption. Everything downstream
scales from that one number, and it is the first thing we would replace with
counts."*

---

## INPUTS

| Input | Type |
|---|---|
| `road` | OSM road object |
| `t` | clock hours |
| `date` | Date |
| `conditions` | weather, incidents, events, closures |
| `slopeDeg` | from DEM, optional |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `q` | number | demand, veh/h |
| `C_eff` | number | effective capacity |
| `x` | number | v/c ratio |
| `speedKmh` | number | actual speed |
| `travelSeconds` | number | link travel time |
| `delaySeconds` | number | delay |
| `los` | string | A–F |
| `congestionIndex` | number | 0–1, for UI |
| `breakdown` | object | every intermediate value, for explainability |

`breakdown` is not optional. It is what allows the AI to answer *"why is this road
red?"* with a real reason instead of a generic one.

---

## CODE SHAPE

```
travelTime(road, t, date, conditions, slopeDeg?) -> {
  q, cEff, x, speedKmh, travelSeconds, delaySeconds, los, congestionIndex, breakdown
}

networkAt(t, date, conditions) -> {
  links: [...],
  networkCongestion, meanLos, worstLinks: [top 3],
  vehicleHoursLost, provenance
}

routeTotals(links) -> { seconds, delaySeconds, los, vehicleHoursLost }
```

**Constraint:** `travelTime` must be **pure and deterministic**. No `Date.now()`,
no `Math.random()` unless a seeded RNG is passed explicitly. Same inputs must
always give the same output — this is what makes the tests meaningful and the
demo repeatable.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `x = 0` | `travelSeconds` equals free-flow exactly |
| Doubling `q` at `x < 0.5` | small delay increase |
| Doubling `q` at `x ≈ 0.9` | large delay increase |
| `closures` contains the road | `C_eff = C_FLOOR`, `x` huge, LOS F |
| Weather `heavy_rain` | `travelSeconds` strictly greater |
| Monotonicity | `travelSeconds` never decreases as `q` rises |
| `breakdown` fields | all present, all finite |
| Determinism | 100 runs, identical output |
| Network aggregation | delay-weighted, not a plain mean |
| `los` vs `congestionIndex` | always consistent (F14 boundaries match UI ramp) |

---

## NOTES

- **`q_base` is the honest weak point.** Everything scales from it. Rather than
  hiding that, expose it: put the `BASELINE_LOAD` table in one place, name it in
  the UI tooltip, and lead with it when someone asks about accuracy. A model that
  names its own weakest assumption is more trustworthy than one that does not.

- **Closures set capacity to the floor, not to zero.** A closed road still exists
  and the maths must not divide by zero. The floor of 150 veh/h represents
  "essentially impassable but not mathematically empty", and `x` becomes enormous,
  producing LOS F correctly.

- **Compute the breakdown, show the number.** A `breakdown` object costs almost
  nothing and turns every answer into an explainable one. This is the difference
  between a model a judge trusts and a model a judge suspects.
