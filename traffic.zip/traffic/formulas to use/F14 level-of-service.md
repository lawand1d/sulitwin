# F14 — Level of Service

**The output grade that drives the badge, the colours and the AI's language**

## PURPOSE

Converts the raw volume/capacity ratio into a letter grade a non-engineer
understands, and into the 0–1 index the map uses for colouring.

A number like `x = 0.82` means nothing to a resident. "Level of Service D —
unstable flow" means something.

---

## EQUATION

```
LOS(x) = A  if x ≤ 0.60
         B  if x ≤ 0.70
         C  if x ≤ 0.80
         D  if x ≤ 0.90
         E  if x ≤ 1.00
         F  if x > 1.00
```

These are the **HCM urban street** thresholds. They are standard, citable, and
should not be adjusted.

### Congestion index for colouring

```
congestionIndex(x) = clamp( (x − 0.30) / 0.90 ,  0, 1 )
```

A separate mapping, on purpose. LOS drives the *words*; the index drives the
*colour*. Keeping them apart lets the UI use a smooth ramp while the label uses
the correct discrete grade.

---

## THE GRADES

| LOS | `x` | Name | What it feels like | Colour |
|---|---|---|---|---|
| **A** | ≤ 0.60 | Free flow | You drive at the speed you expect | `#4aa08f` |
| **B** | ≤ 0.70 | Stable | Slightly slower, no real constraint | `#7fa86a` |
| **C** | ≤ 0.80 | Stable, constrained | You notice the traffic | `#e0973f` |
| **D** | ≤ 0.90 | Approaching unstable | Speeds drop noticeably, hard to change lanes | `#d97a4a` |
| **E** | ≤ 1.00 | Unstable | At capacity. Any disturbance causes a breakdown | `#c1553f` |
| **F** | > 1.00 | Forced / breakdown | Stop-and-go. Demand exceeds what the road can serve | `#8c2f22` |

Colours match the ramp specified in `INTEGRATION.md` §3a, and reuse the project's
existing zone-class palette so the whole map stays coherent.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance |
|---|---|---|---|
| LOS thresholds | 0.60 / 0.70 / 0.80 / 0.90 / 1.00 | HCM standard | STANDARD |
| `indexLow` | index zero point | 0.30 | DESIGN |
| `indexSpan` | index range | 0.90 | DESIGN |

**The thresholds are standard. The index mapping is a design choice** — pick it so
that the demo block uses the middle of the colour ramp at a typical peak, rather
than saturating to red everywhere.

---

## INPUTS

| Input | Type |
|---|---|
| `x` | number, v/c ratio |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `los(x)` | string | `'A'…'F'` |
| `congestionIndex(x)` | number | 0–1 |
| `losColour(x)` | string | hex |
| `losLabelKey(x)` | string | i18n key, e.g. `'los.D'` |

---

## CODE SHAPE

```
los(x)              -> 'A'|'B'|'C'|'D'|'E'|'F'
congestionIndex(x)  -> number in [0,1]
losColour(x)        -> hex string
losLabelKey(x)      -> i18n key
LOS_THRESHOLDS      -> exported
```

**Constraint:** `los` must be a pure step function with **no gaps and no
overlaps**. Test the exact boundary values 0.60, 0.70, 0.80, 0.90, 1.00.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `los(0.60)` | `'A'` (boundaries belong to the lower grade) |
| `los(0.61)` | `'B'` |
| `los(1.00)` | `'E'` |
| `los(1.01)` | `'F'` |
| `los(0)` | `'A'` |
| `los(-1)` | `'A'` — clamped, never throws |
| `los(999)` | `'F'` |
| `congestionIndex(0.30)` | exactly 0 |
| `congestionIndex(1.20)` | exactly 1 |
| Continuity | no two adjacent inputs differ by more than one grade |
| Colour ↔ LOS | `losColour` and `los` never disagree |

---

## THE AI'S VOCABULARY

F14 defines the words the assistant is allowed to use. Keep this table in the
prompt so the language stays consistent and non-technical.

| LOS | English phrase | Sorani phrase |
|---|---|---|
| A | flowing freely | بە ئاسانی دەڕوات |
| B | light traffic | هاتوچۆی سووک |
| C | moderate traffic | هاتوچۆی مامناوەند |
| D | heavy — expect delays | هاتوچۆی قورس — چاوەڕوانی دواکەوتن بکە |
| E | at capacity — serious delays | لە ئاستی توانادایە — دواکەوتنی زۆر |
| F | gridlocked | هاتوچۆ ڕاگیراوە |

---

## NOTES

- **Never present `x` to a non-technical user without an LOS.** `x = 0.87` invites
  the question "is that bad?" and the model should answer it, not the resident.

- **Never present an LOS without its time and provenance.** "LOS D" alone is
  meaningless. "LOS D at 08:00, estimated" is a fact.

- **LOS F is a claim.** It says the road has broken down. Before showing F, check
  that `x > 1.0` came from a real demand estimate and not from a capacity flooring
  artefact. A bug that floors capacity to 150 will make every road LOS F — which
  is exactly why the validation table above tests `x` at both ends.

- Keep the colours identical to `INTEGRATION.md` §3a. Two files declaring the same
  ramp in two places is how they drift apart.
