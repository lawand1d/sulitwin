# F06 — Speed-flow relationship ★

**The core equation.** Everything else in this model feeds into it or reads out
of it.

## PURPOSE

Converts demand and capacity into an actual speed and travel time. This is what
turns "this road is busy" into "this road takes 6 minutes instead of 3".

---

## EQUATION — the BPR volume-delay function

```
                    t  =  t₀ · ( 1 + α · x^β )
```

| Symbol | Meaning |
|---|---|
| `t₀` | free-flow travel time (seconds) |
| `t` | congested travel time (seconds) |
| `x` | volume/capacity ratio = `q / C` |
| `α` | calibration constant |
| `β` | calibration constant |

**Standard values: α = 0.15, β = 4.** These come from the US Bureau of Public
Roads and are the most widely used speed-flow relationship in transport planning.
They are not a guess — they are the textbook default, and being able to name them
is worth more than any custom curve.

### Direct speed form

```
speedFactor(x) = 1 / (1 + α · x^β)

v(x) = v₀ · speedFactor(x)
```

### With a breakdown floor

Pure BPR approaches zero speed asymptotically and never quite breaks down. Real
traffic does. Add a floor:

```
speedFactor(x) = max( MIN_FACTOR,  1 / (1 + α·x^β) )
```

| Constant | Value | Meaning |
|---|---|---|
| `MIN_FACTOR` | **0.18** | speed cannot fall below 18% of free flow |

Once `x > 1` the road is oversaturated and queuing takes over — that is **F10**'s
job, not this formula's.

---

## Local calibration — and why α differs here

`α = 0.15` assumes good signal coordination, disciplined lane use and homogeneous
vehicles. Sulaimani has none of those in equal measure.

| Condition | Effect on α |
|---|---|
| Poor signal coordination | ↑ |
| Mixed traffic (minibuses, pickups, motorcycles, handcarts) | ↑ |
| Undisciplined lane use / on-street parking | ↑ |
| Narrow lanes | ↑ |
| Steep gradients | ↑ |

**Recommended local values:**

| Road type | α | β |
|---|---|---|
| Motorway / trunk | 0.15 | 4 |
| Primary arterial | **0.20** | 4 |
| Secondary | **0.22** | 4 |
| Tertiary | **0.25** | 4 |
| Residential / service | **0.28** | 4 |

Keep `β = 4`. Varying both makes the model uncalibratable. Vary `α` only, and
state that you did.

> Say this out loud if asked: *"we use the standard BPR curve, and we raised α
> above the textbook 0.15 for local road types because signal coordination and
> lane discipline here are weaker. That is a documented local adjustment, not a
> fudge factor."*

---

## Free-flow speed `v₀`

```
v₀ = maxspeed tag  if present
   | CLASS_SPEED[highway]  otherwise
   | v₀ × 0.85  if surface is unpaved or cobblestone
```

| OSM class | Default `v₀` km/h |
|---|---|
| motorway | 90 |
| trunk | 80 |
| primary | 60 |
| primary_link | 45 |
| secondary | 50 |
| secondary_link | 40 |
| tertiary | 40 |
| tertiary_link | 35 |
| unclassified | 30 |
| residential | 30 |
| living_street | 15 |
| service | 15 |

Then apply the terrain penalty (shared with **F05**):

```
v₀_effective = v₀ × (1 − 0.35 × sin(slopeDeg))
```

A 6° hill costs about 4% of free-flow speed; a 12° hill about 7%. Gradient also
matters more for heavy vehicles — this is a simplification, documented as one.

---

## The shape of the curve

| `x` (v/c) | `speedFactor` (α=0.15) | Meaning |
|---|---|---|
| 0.0 | 1.00 | empty |
| 0.3 | 0.99 | free flow |
| 0.5 | 0.96 | stable |
| 0.7 | 0.85 | approaching capacity |
| 0.8 | 0.75 | unstable |
| 0.9 | 0.60 | near capacity |
| 1.0 | 0.40 | at capacity |
| 1.2 | 0.27 | oversaturated |
| 1.5 | 0.18 | floor — gridlock |

**The curve is flat then falls off a cliff.** That is the correct shape and it is
what makes the model feel right: a road at 50% load looks fine, and the same road
at 95% looks broken. It is also why small demand increases near capacity cause
disproportionate delay — which is the single most useful insight this model gives
a planner.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `α` | BPR coefficient | table above | ESTIMATED (standard + local) | speed-flow survey |
| `β` | BPR exponent | 4 | STANDARD | — |
| `MIN_FACTOR` | breakdown floor | 0.18 | ESTIMATED | observed crawl speed |
| `CLASS_SPEED` | free-flow speeds | table above | ESTIMATED | GPS probe data |
| `terrainPenalty` | gradient factor | formula above | **MEASURED inputs** (DEM) | DEM |

---

## INPUTS

| Input | Type | Notes |
|---|---|---|
| `q` | number | demand, vehicles/hour — from F01×F02×F03×F04 |
| `C` | number | capacity — from F05 |
| `v0` | number | free-flow speed km/h |
| `length` | number | segment length, metres |
| `slopeDeg` | number | optional |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `x` | number | v/c ratio |
| `speedKmh` | number | actual speed |
| `speedFactor` | number | 0.18 – 1.0 |
| `travelSeconds` | number | segment travel time |
| `delaySeconds` | number | `travelSeconds − freeFlowSeconds` |

---

## CODE SHAPE

```
speedFactor(x, alpha)               -> number in [MIN_FACTOR, 1]
speedFromFlow(v0, q, capacity, alpha) -> number km/h
travelTime(length, v0, q, capacity, alpha) -> { seconds, freeFlowSeconds, delaySeconds }
bprAlpha(highway)                   -> number
CLASS_SPEED                         -> exported table
```

**Constraint:** must be a **monotonically non-increasing** function of `q`. This
is the model's most important invariant — more demand can never mean less delay.
Test it with a sweep.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `speedFactor(0)` | exactly 1.0 |
| `speedFactor(1)` | 0.38 – 0.42 (α=0.15) |
| `speedFactor(10)` | equals `MIN_FACTOR` |
| Monotonicity | for q increasing 0→3C, speed never rises |
| `travelTime` at `q = 0` | equals `length / v0` exactly |
| Doubling `length` | exactly doubles both time and delay |
| Continuity | no jump greater than 1% between adjacent test points |
| `delaySeconds` | never negative |

---

## NOTES

- **BPR under-predicts delay above `x ≈ 1.1`.** That is known and documented. It
  is why **F10** (queueing) exists — beyond capacity, queue delay dominates and
  BPR alone is not enough. Do not try to fix this by inflating `α`; that breaks
  the well-behaved region below capacity.

- **Do not apply BPR per road segment and sum naively.** Delay accumulates: a
  vehicle arriving late at the next segment meets a different demand. Full
  treatment is a traffic assignment problem (**F11**). For this application,
  applying it per segment and summing is an accepted simplification — **state it
  as one**.

- The single most valuable output for the AI is the **delay**, not the speed.
  "This road is slow" means nothing. "Closing it adds 4 minutes to 1,900
  vehicles, which is 127 vehicle-hours a day" means something.

- Convert to a human unit somewhere:
  `vehicleHoursLost = Σ (delaySeconds × q) / 3600`
  That number is what a planner takes to a council meeting.
