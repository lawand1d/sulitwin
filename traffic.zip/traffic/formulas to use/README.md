# formulas to use

One file per formula. Each file is self-contained: it states what it computes,
the equation, its parameters, its inputs and outputs, and what real data would
replace its estimates.

---

## Index

| File | Computes | Depends on | Standard? |
|---|---|---|---|
| [F01](F01%20demand-profile.md) | Demand over the 24-hour clock | — | local calibration |
| [F02](F02%20day-of-week.md) | Day-of-week multipliers | — | local calibration |
| [F03](F03%20seasonal-and-ramadan.md) | Season, Ramadan, holiday multipliers | — | local calibration |
| [F04](F04%20events.md) | Temporary demand spikes | — | standard |
| [F05](F05%20road-capacity.md) | Road capacity in vehicles/hour | D1–D6, D10, D11 | standard |
| [F06](F06%20speed-flow.md) | **Speed and travel time from demand** | F01–F05 | **BPR, standard** |
| [F07](F07%20intersection-delay.md) | Delay at signals and junctions | F05, F06, D7 | Webster / HCM |
| [F08](F08%20weather.md) | Weather speed and capacity penalties | — | standard |
| [F09](F09%20incidents.md) | Incident delay and duration | F06 | standard |
| [F10](F10%20queue-length.md) | Queue length and dissipation | F06, F07 | standard |
| [F11](F11%20route-choice.md) | Which route a driver picks | F07, F08, F10 | logit, standard |
| [F12](F12%20prediction.md) | 15–30 minute forecast | F01 + history | standard |
| [F13](F13%20composite-travel-time.md) | **The master equation** | all of the above | composition |
| [F14](F14%20level-of-service.md) | LOS grade A–F | F06 | HCM thresholds |

★ F06 and F13 are the two that matter most. Read those first if short on time.

---

## The dependency graph

```
   ┌─────────────────────────── temporal ───────────────────────────┐
   │  F01 demand      F02 day-of-week     F03 seasonal     F04 events │
   └───────────────────────────────┬────────────────────────────────┘
                                   │
   ┌───────────── network ─────────┴──────── conditions ────────────┐
   │  F05 capacity        F08 weather       F09 incidents           │
   └───────────────────────────────┬────────────────────────────────┘
                                   ▼
                          ╔════════════════╗
                          ║  F06 SPEED-FLOW ║   ← BPR. the heart.
                          ╚════════┬═══════╝
                                   │
              ┌────────────────────┼────────────────────┐
              ▼                    ▼                    ▼
        F07 intersection      F10 queue           F14 level of service
              │                    │                    │
              └────────┬───────────┘                    │
                       ▼                                │
                 F11 route choice                       │
                       │                                │
                       └────────────┬───────────────────┘
                                    ▼
                        ╔═══════════════════════╗
                        ║ F13 COMPOSITE TIME     ║
                        ╚═══════════┬═══════════╝
                                    │
                    ┌───────────────┴───────────────┐
                    ▼                               ▼
              private/ P01–P05                 public/ B01–B06
                 (cars, taxis)                      (bus)
```

---

## Notation used throughout

| Symbol | Meaning | Unit |
|---|---|---|
| `t` | time of day | hours, 0–24, fractional |
| `d` | day of week | 0=Sunday … 6=Saturday |
| `q` | demand (arriving volume) | vehicles/hour |
| `C` | capacity | vehicles/hour |
| `x` | `q / C`, the volume-capacity ratio | dimensionless |
| `v0` | free-flow speed | km/h |
| `v` | actual speed | km/h |
| `t0` | free-flow travel time | seconds |
| `t` | actual travel time | seconds |
| `D` | total delay | seconds |
| `PCU` | passenger car unit | dimensionless |

---

## How to use one of these files

Each has the same sections:

```
PURPOSE         what it computes, in one sentence
EQUATION        the mathematics
PARAMETERS      every constant, with current value and real-data replacement
INPUTS          what it needs
OUTPUTS         what it returns
CODE SHAPE      the interface the implementation must expose
VALIDATION      how to prove it is not wrong
NOTES           edge cases, local quirks, gotchas
```

An AI converting a file to code should produce **one module per file**, with the
`CODE SHAPE` interface, using only the `PARAMETERS` for constants, and shipping
the `VALIDATION` checks as tests.
