# F12 — Short-term prediction

**Predictive elements → 15–30 minute forecast, historical patterns**

## PURPOSE

Forecasts congestion 15–30 minutes ahead by blending the historical daily profile
with what is happening right now.

This is the formula behind *"this corner always jams at 8:15"* — and behind the
honest admission that we cannot forecast further than about half an hour.

---

## EQUATION — blended forecast

```
ŷ(t + h) = w_h · H(t + h)  +  (1 − w_h) · E(t + h)
```

| Symbol | Meaning |
|---|---|
| `H(t+h)` | **historical** value at that future time — from F01×F02×F03 |
| `E(t+h)` | **extrapolated** value from the current observation |
| `w_h` | blend weight, depends on horizon `h` |

### Blend weight — history wins as the horizon grows

```
w_h = 1 − exp( −h / τ )          τ = 20 minutes
```

| Horizon `h` | `w_h` | Meaning |
|---|---|---|
| 0 min | 0.00 | now — trust the observation entirely |
| 10 min | 0.39 | mostly current |
| 15 min | 0.53 | even split |
| 30 min | 0.78 | mostly history |
| 60 min | 0.95 | history effectively alone |
| 120 min | 1.00 | pure profile |

**This is why the model refuses to forecast beyond 60 minutes.** At long horizons
it has nothing but the daily profile, which is not a forecast — it is a timetable.
Say that rather than producing a confident number the model cannot support.

### Extrapolation term

Use a simple trend-corrected estimate:

```
E(t + h) = obs(t)  +  h · trend
trend    = ( obs(t) − obs(t − 15min) ) / 15min      clamped to ±3 %/min
```

The clamp matters. Without it, a single noisy observation produces an absurd
extrapolation. Traffic trends do not continue at 20% per minute.

### Optional smoothing of the observation

```
obs_smooth(t) = α · obs(t) + (1 − α) · obs_smooth(t − Δt)      α = 0.3
```

`α = 0.3` responds within about three sample periods without chasing noise.

---

## HISTORICAL PATTERN STORE

For "this corner always jams at 8:15" the model needs memory. Store per-road,
per-(dayType, hour, 5-min slot):

```
history[roadId][dayType][slot] = { mean, count, variance }
```

Update on every observation with a **running mean**:

```
mean_new = mean_old + ( x − mean_old ) / ( count + 1 )
count   += 1
```

Do not store raw observations — they grow without bound. Store the sufficient
statistics only.

### Anomaly flag

The interesting output is not the forecast. It is the **departure from the
pattern**:

```
anomaly = ( obs(t) − history[road][dayType][slot].mean )
          / max( history[...].stdDev, MIN_STD )
```

| `anomaly` | Meaning the AI can state |
|---|---|
| < 1.0 | normal for this time |
| 1.0 – 2.0 | busier than usual — {{pct}}% above typical |
| > 2.0 | **unusual — something is wrong here** |

That last line is the one worth having. A model that can say *"this is not normal
for a Tuesday at 08:15, something has happened"* is genuinely useful, and it is
where prediction connects to incident detection.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `τ` | blend time constant | 20 min | ESTIMATED | backtest |
| `α` | smoothing factor | 0.3 | ESTIMATED | backtest |
| `trendClamp` | maximum trend | ±3 %/min | ESTIMATED | backtest |
| `MIN_STD` | variance floor | 0.02 | ESTIMATED | backtest |
| `maxHorizon` | forecast limit | **60 min** | DESIGN | — |

**How to calibrate:** collect two weeks of observations. Forecast each 15-minute
point using only data before it. Compare to what happened. Tune `τ` and `α` to
minimise error. This is a genuine, achievable Phase 1 study and it turns every
number in this table from ESTIMATED to MEASURED.

---

## INPUTS

| Input | Type |
|---|---|
| `roadId` | string |
| `t` | number, now |
| `h` | number, horizon in minutes |
| `observation` | number \| null, current measured v/c if available |
| `history` | the pattern store |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `forecast(roadId, h)` | number | predicted v/c |
| `confidence(h)` | number | 1 − `w_h` inverse — shrinks with horizon |
| `anomaly(roadId, t)` | number | standard deviations from pattern |
| `patternLabel(roadId, t)` | string | `'typical' \| 'busier' \| 'unusual'` |

---

## CODE SHAPE

```
forecast(roadId, t, h, history, observation?) -> { vc, los, confidence }
anomaly(roadId, t, history, observation)      -> number
updateHistory(roadId, dayType, slot, x)       -> void
blendWeight(h)                                -> number
createHistoryStore()                          -> empty store
```

**Constraint:** `forecast` with `observation === null` must return the pure
historical profile with `confidence = 0` — not an error. Cold start is the normal
case, not an exception.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `h = 0` | returns the observation exactly |
| `h = 120` | returns the historical profile exactly |
| `h > maxHorizon` | flagged as out-of-range, not silently extrapolated |
| Confidence | monotonically decreasing in `h` |
| `updateHistory` 1000× | `mean` converges to the true mean |
| `anomaly` with no history | returns 0, not `NaN` |
| Trend clamp | a 50%/min jump is clamped to 3%/min |
| No observation | returns profile with confidence 0 |

---

## NOTES

- **The 60-minute limit is a feature, not a shortcoming.** Stating a limit and
  explaining why is more credible than a number the model invented. Train the
  presenter to say: *"we forecast half an hour ahead because beyond that we would
  only be reading the daily pattern back to you, and calling that a forecast
  would be dishonest."*

- **Prediction is where this model stops being a description and becomes a tool.**
  Everything else says "here is the traffic". F12 says "here is what is about to
  happen" — which is what a commuter actually wants and what a planner needs to
  act in time.

- The anomaly detector is the natural hook for **F09**. When `patternLabel`
  returns `'unusual'`, that is the model telling you an incident probably exists
  before anyone reports it. Real cities spend a lot of money on this. Here it is
  three lines, and it works because the historical pattern is stable.

- **Persist the history store.** It is the only part of this model that learns.
  Losing it on reload means the model never improves — and the "learns over time"
  claim in the pitch stops being true.
