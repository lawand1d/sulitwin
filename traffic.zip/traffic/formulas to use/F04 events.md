# F04 — Events

**Temporal factors → events causing temporary spikes**

## PURPOSE

Adds short-lived demand around a specific place at a specific time — a football
match, a concert, a funeral procession, a wedding, a protest, a market day.

Handled separately from F01–F03 because events are **localised** and
**asymmetric**: the egress spike when everyone leaves at once is far sharper than
the ingress trickle.

---

## EQUATION

An event contributes additional vehicle demand to roads near it:

```
Δq(road, t) =  N_cars
             × spatialDecay(distance(road, event))
             × temporalProfile(t − event.start, event.duration)
```

### 1. Car demand from attendance

```
N_cars = attendance × carModeShare / avgOccupancy × (1 − transitShare)
```

### 2. Spatial decay

```
spatialDecay(d) = exp( −d² / (2σ_ev²) )
```

σ_ev scales with event size — a stadium affects a wider area than a wedding hall:

```
σ_ev = clamp(150 + 0.35 × sqrt(attendance), 150, 900)   metres
```

### 3. Temporal profile — asymmetric on purpose

```
temporalProfile(τ) =  ingress(τ) + egress(τ)

ingress(τ) = A_in  × exp( −(τ − t_in)² / (2σ_in²) )
egress(τ)  = A_out × exp( −(τ − t_out)² / (2σ_out²) )
```

| Phase | Centre | Width | Peak |
|---|---|---|---|
| Ingress | `−0.5 × duration` (i.e. arriving before start) | 0.4 × duration | 0.45 × N_cars |
| Egress | `+0.1 × duration` (just after the end) | 0.18 × duration | 1.00 × N_cars |

**The egress peak is more than twice the ingress peak and half as wide.** This is
the whole point of modelling events separately. Everyone arrives over an hour;
everyone leaves in fifteen minutes.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `carModeShare` | share arriving by car | 0.70 | ESTIMATED | event travel survey |
| `avgOccupancy` | persons per car | 2.4 | ESTIMATED | car-park counts |
| `transitShare` | share using bus/taxi | 0.15 | ESTIMATED | survey |
| `σ_ev` | spatial spread | formula above | ESTIMATED | observed queue extent |
| ingress/egress timing | ratios above | — | ESTIMATED | observed arrival/departure curves |

### Default attendances (for events with no known figure)

| Event type | Typical attendance | Notes |
|---|---|---|
| Football, local derby | 8,000 | Kamal Salim Stadium is in the demo block |
| Football, ordinary | 2,500 | |
| Concert / festival | 3,000 | |
| Wedding hall | 400 | but near-simultaneous egress |
| Funeral / procession | 1,500 | moves along a route, not a point — see below |
| Protest | 1,000 | |
| Friday prayers | 2,000 | already partly captured by F02 |

---

## SPECIAL CASE — moving events

Processions (funerals, Nowruz celebrations, protests) are not point events. They
are a **moving demand front** along a path:

```
for each road r on the route:
    Δq(r, t) += N_cars × frontWidth(t − arrivalTime(r))
```

`arrivalTime(r)` = cumulative route length to `r` ÷ procession speed (~5 km/h).

Treat the front as a Gaussian with σ ≈ 0.15 h. This produces a rolling wave of
congestion along the route, which is exactly what a procession does.

---

## INPUTS

| Input | Type | Notes |
|---|---|---|
| `events` | array | `{ id, name, type, lat, lon, start, duration, attendance?, route? }` |
| `roads` | array | for distance computation |
| `t` | number | current clock hours |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `eventDemand(roadId, t)` | number | extra vehicles/hour on that road |
| `activeEvents(t)` | array | events currently influencing the network |
| `eventImpact(eventId)` | object | peak Δq, affected road count, worst road |

---

## CODE SHAPE

```
eventDemand(road, t, events)   -> number  (vehicles/hour to ADD)
activeEvents(t, events)        -> array
eventSpatialSigma(attendance)  -> number  (metres)
eventTemporalProfile(tau, duration) -> number
```

**Constraint:** `eventDemand` **adds** to `F01`'s baseline. It never replaces it
and never scales it. Keep the two additive so an event can be removed cleanly.

---

## VALIDATION

| Test | Expectation |
|---|---|
| Egress peak | > 2 × ingress peak |
| Egress width | < 0.5 × ingress width |
| `eventDemand` 5 km away | < 1% of peak |
| `eventDemand` at the venue | equals `N_cars` at egress peak |
| Event removed | demand returns exactly to baseline (no residue) |
| Duration doubled | width doubles, peak does not |

---

## NOTES

- **Egress is what jams a city, not ingress.** If a demo shows one event
  behaviour, show a stadium emptying: the surrounding roads go red within fifteen
  minutes and recover over an hour.

- **Kamal Salim Stadium is inside the demo block** (OSM way 775085220,
  35.5685–35.5697 N, 45.4445–45.4459 E). A football event there is the most
  compelling and most locally recognisable event demo available. Use it.

- **This is the one place a human should be able to type data live.** Real
  incidents and events are unknown in advance. Expose them as editable inputs so
  a user can add "match at the stadium tonight, 8,000 people" and watch the model
  respond. That is a genuine planning tool, not a simulation toy.

- Events are the natural bridge to **F08/F09** — an event that overwhelms a
  junction becomes an incident.
