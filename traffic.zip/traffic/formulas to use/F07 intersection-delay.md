# F07 — Intersection delay

**Road network factors → intersections and signals create bottlenecks**

## PURPOSE

Adds delay at junctions. A road segment's own speed is often fine; the delay is
sitting at the signal at the end of it. Ignoring intersections makes a model that
says a congested city is free-flowing.

---

## WHY THIS MATTERS MORE HERE THAN IN A TEXTBOOK

Most congestion in a city like Sulaimani is **junction congestion**, not link
congestion. Roads are short, blocks are small, and a single unsynchronised
junction backs traffic up along an entire street. A model without F07 will
under-predict delay badly on exactly the corridors people complain about.

---

## EQUATION

Total control delay at an intersection, in seconds per vehicle:

```
d = d₁ + d₂
```

### 1. Uniform delay (Webster)

```
d₁ = 0.5 · CYC · (1 − λ)²  /  ( 1 − min(1, X) · λ )
```

| Symbol | Meaning |
|---|---|
| `CYC` | signal cycle length, seconds |
| `λ` | green ratio = effective green ÷ cycle |
| `X` | degree of saturation = `q / (capacity × λ)` |

### 2. Overflow (incremental) delay — HCM

```
d₂ = 900 · T · [ (X − 1) + √( (X − 1)² + 4·X / (cap · T) ) ]
```

| Symbol | Meaning |
|---|---|
| `T` | analysis period, hours (use **0.25** = 15 minutes) |
| `cap` | approach capacity, veh/h |

`d₂` is near zero when `X < 0.8` and grows sharply above it. This is the term
that reproduces "the junction falls apart at 08:15".

### 3. Unsignalized intersections

For give-way and stop-controlled junctions, use the simpler gap-acceptance form:

```
d_unsig = 1.5 · t_s + 0.9 · t_r  +  ...     (HCM empirical form)

simplified:   d_unsig = 4 + 120 · X³        seconds   (calibrated for this model)
```

For roundabouts:

```
d_rnd = 3 + 90 · X³                          seconds
```

Both simplified forms are monotone in `X` and produce the right shape. **They are
calibrated approximations, not HCM-compliant.** Label them as such.

---

## DETECTING INTERSECTIONS

| Source | Detection |
|---|---|
| `highway=traffic_signals` node | signalised |
| `junction=roundabout` way | roundabout |
| ≥ 3 road segment endpoints sharing a coordinate | junction |
| `highway=stop` / `give_way` node | unsignalized control |
| `crossing` node with `crossing=traffic_signals` | pedestrian signal (adds ~4 s) |

Before assuming: query Overpass for `highway=traffic_signals` across the demo
block and commit the result. It is a small query and it removes a whole class of
guesswork.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `CYC` | signal cycle length | **90 s** | ESTIMATED | signal controller logs |
| `λ` | green ratio | **0.48** | ESTIMATED | signal timing plans |
| `T` | analysis period | 0.25 h | STANDARD | — |
| `d_unsig` coefficients | 4, 120 | ESTIMATED | local junction survey |
| `d_rnd` coefficients | 3, 90 | ESTIMATED | local junction survey |
| `pedDelay` | pedestrian signal penalty | 4 s | ESTIMATED | observation |

For reference, HCM typical cycle lengths run 60–120 s. **90 s is the assumption.**
If real timings arrive, this single number moves the whole city's delay profile.

---

## INPUTS

| Input | Type | Notes |
|---|---|---|
| `q` | number | approach demand, veh/h |
| `capacity` | number | approach capacity from F05 |
| `type` | string | `'signal' \| 'roundabout' \| 'giveway' \| 'none'` |
| `CYC`, `λ` | number | optional overrides |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `delaySeconds` | number | control delay per vehicle |
| `d1`, `d2` | number | the two components, separately |
| `X` | number | degree of saturation |
| `queueAtEnd` | number | vehicles remaining at end of green (feeds F10) |

---

## CODE SHAPE

```
intersectionDelay(q, capacity, type, CYC?, lambda?) -> { total, d1, d2, X, queueAtEnd }
findIntersections(roads, osmNodes)                 -> junction list
junctionType(node)                                 -> string
DEFAULTS                                           -> exported parameter table
```

**Constraint:** `delaySeconds` must be monotone non-decreasing in `q` and
non-negative everywhere. Both components must stay non-negative even when
`X > 1` — the HCM formula's square root handles this, but a naive implementation
will produce `NaN`. Test `X = 2` explicitly.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `X = 0.3` | delay < 12 s |
| `X = 1.0` | delay 35 – 65 s |
| `X = 2.0` | delay > 90 s, finite, positive |
| `X = 2.0` | no `NaN` (the square root term is the trap) |
| Monotonicity | delay never falls as `q` rises |
| `d2` at `X = 0.5` | near zero |
| Roundabout vs signal at same `X` | roundabout lower below `X ≈ 0.6`, higher above |
| `lambda = 0` | handled without division by zero |

---

## NOTES

- **`X` is not the same as `x` in F06.** F06's `x` is link v/c; F07's `X` is
  *degree of saturation* = `q / (capacity × λ)`. Conflating them is the most
  common error in implementations of this model. Name the variables distinctly in
  code — `linkVC` and `degreeOfSaturation`.

- **A junction cannot be evaluated from one road.** It needs the demand summed
  across all approaches competing for the same green. Build the junction as an
  object that owns its approaches.

- Roundabouts are common in Sulaimani and behave quite differently from signals.
  Do not model them as signals.

- The pedestrian-signal penalty is small per vehicle but matters for the
  walkability story elsewhere in the product. Keep it as a parameter even if it
  is not used in the demo.
