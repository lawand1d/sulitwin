# F10 — Queue length and dissipation

**Real-time conditions → queue length, current backups**

## PURPOSE

Tracks how many vehicles are queued at a point or on a link, how long the queue
physically is, and how long it takes to clear once the cause goes away.

F06 (BPR) describes a road *below* capacity. F10 describes what happens *above*
it, where BPR is known to be inadequate. This is the difference between "slow"
and "gridlocked".

---

## EQUATION — deterministic queueing

Track queue length `L` in vehicles over time steps `Δt`:

```
L(t + Δt) = max( 0,  L(t) + ( q(t) − C_eff(t) ) · Δt )
```

| Symbol | Meaning |
|---|---|
| `q(t)` | arriving demand, veh/h |
| `C_eff(t)` | effective capacity after F05, F08, F09 |
| `Δt` | time step, hours (use 1/12 = 5 minutes) |

When `q > C_eff` the queue grows linearly at the oversaturation rate.
When `q < C_eff` it drains at the difference rate.

### Queue length in metres

```
L_metres = L_vehicles × L_vehicle / lanes

L_vehicle = 7.0 m   (average vehicle + gap in a standing queue)
```

### Time to clear

```
T_clear = L_vehicles / (C_eff − q)        hours,  requires q < C_eff
```

If `q ≥ C_eff`, the queue **never clears** — it grows without bound until demand
falls. This is the definition of gridlock and the model must be able to say so
rather than returning a finite number.

### Shockwave speed (optional refinement)

The speed at which the back of the queue moves upstream:

```
w = (q_downstream − q_upstream) / (k_downstream − k_upstream)
```

Useful for showing *where* a queue will reach, and for deciding whether it will
spill back into the previous junction. Requires density `k`; approximate with
`k = q / v`. Implement only if the spill-back visual is wanted.

---

## INPUTS

| Input | Type | Notes |
|---|---|---|
| `q` | number | current demand |
| `C_eff` | number | effective capacity |
| `L_prev` | number | queue at previous step |
| `dt` | number | hours |
| `lanes` | number | for length conversion |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `queueVehicles` | number | ≥ 0 |
| `queueMetres` | number | physical extent |
| `secondsToClear` | number \| `null` | `null` = will not clear |
| `oversaturated` | boolean | `q ≥ C_eff` |

---

## CODE SHAPE

```
stepQueue(q, cEff, lPrev, dt)   -> { queueVehicles, oversaturated }
queueLengthMetres(vehicles, lanes) -> number
timeToClear(vehicles, cEff, q)  -> number | null
simulateDay(day, dt)            -> queue timeseries for the whole day
```

**Constraint:** `queueVehicles` must never be negative, and `timeToClear` must
return `null` — not `Infinity`, not a huge number — when the queue cannot clear.
Callers must handle `null` explicitly. It is the model's way of saying
*"this does not recover on its own"*.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `q < C_eff`, `L = 0` | stays 0 |
| `q > C_eff` for 1 h at 20% over | queue ≈ 0.2 × C_eff vehicles |
| `q = C_eff` | queue unchanged |
| Demand drops to 0 | queue drains to 0 in the predicted time |
| `timeToClear` when `q ≥ C_eff` | exactly `null` |
| Negative queue | never occurs, from any input |
| Full day at Δt = 5 min | queue returns to 0 by 02:00 |
| Conservation | ∫(q − C_eff)dt over the day, when negative at night, matches total queue cleared |

---

## NOTES

- **This is the formula that makes the model honest about gridlock.** A model
  with only F06 will always report a finite, recoverable delay — it cannot say
  "this junction will not recover". F10 can, and that is exactly the finding a
  planner needs. *"At this demand level the junction does not clear before the
  evening peak begins"* is a genuinely important result.

- **Peak spreading.** Real demand does not stay constant while queued; drivers
  shift their departure time. If the model shows a queue that never clears, that
  is a signal that in reality the peak would spread. Note this as a documented
  limitation rather than trying to model it in Phase 0.

- **The 5-minute time step is deliberate.** At 15 minutes, queues build and clear
  in visible steps and the animation looks wrong. At 1 minute it is needlessly
  expensive. 5 minutes matches the slider granularity in INTEGRATION.md §2.

- Queue length in **metres** is the number to show a human. "A 340-metre queue
  back from the junction" is instantly understood. "17 vehicles queued" is not.
