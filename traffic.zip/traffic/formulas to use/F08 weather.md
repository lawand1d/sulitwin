# F08 — Weather

**Real-time conditions → weather affects speeds and safety**

## PURPOSE

Applies speed and capacity penalties for rain, snow, dust and low visibility.

Small per-vehicle effect, large aggregate effect — and it is the factor a normal
resident understands instantly ("it's raining, of course it's slow").

---

## EQUATION

```
v_actual = v_F06  ×  f_speed(weather)
C_actual = C_F05  ×  f_capacity(weather)
```

Both factors apply **before** the BPR curve, not after. Weather reduces the road's
*free-flow speed* and its *capacity*; the congestion response then follows
naturally from F06.

---

## FACTOR TABLE

| Condition | `f_speed` | `f_capacity` | Notes |
|---|---|---|---|
| `clear` | 1.00 | 1.00 | |
| `light_rain` | 0.94 | 0.97 | first 30 min worse — oil on dry road |
| `rain` | 0.88 | 0.93 | |
| `heavy_rain` | 0.78 | 0.85 | standing water, spray |
| `storm` | 0.65 | 0.75 | |
| `snow_light` | 0.70 | 0.80 | rare but disruptive here |
| `snow_heavy` | 0.50 | 0.60 | |
| `ice` | 0.40 | 0.55 | |
| `dust` | 0.85 | 0.95 | visibility-limited; common in summer |
| `fog` | 0.75 | 0.90 | |

These are consistent with the published wet-weather speed-reduction literature
(typically 3–15% for light rain, up to 30%+ for heavy rain). They are stated as
ESTIMATED because they have not been measured *for Sulaimani*.

---

## The first-rain penalty

The first rain after a dry spell is measurably worse — accumulated oil and dust
make the surface slippery. This is a real effect and a nice detail:

```
if rain started < 30 minutes ago AND previous 72 h were dry:
    f_speed    ×= 0.92
    f_capacity ×= 0.95
```

Track `lastRainAt` and `dryHours`.

---

## Seasonal interaction

Weather does not multiply the seasonal factor independently. Two rules:

1. **Winter rain** in Sulaimani is heavier and more disruptive than summer rain.
   Apply `f_speed ×= 0.95` for rain in Dec–Feb.
2. **Summer dust** (`dust` condition) is common Jun–Aug. Trigger it from wind
   speed rather than requiring an explicit input:

```
if month in [6,7,8] AND windSpeed > 25 km/h AND daysSinceRain > 14:
    weather = 'dust'
```

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `f_speed` | speed factors | table above | ESTIMATED | matched rain/speed study |
| `f_capacity` | capacity factors | table above | ESTIMATED | matched rain/flow study |
| `firstRainWindow` | minutes | 30 | ESTIMATED | local observation |
| `dryHours` | dry spell threshold | 72 | ESTIMATED | local observation |
| `dustWindThreshold` | km/h | 25 | ESTIMATED | meteorological |

**How to get the real values:** pair historical rainfall records with observed
speeds on the same road at the same hour. Two months of data gives a defensible
`f_speed` for `rain` and `heavy_rain`. That is a realistic Phase 1 study.

---

## INPUTS

| Input | Type | Values |
|---|---|---|
| `weather` | string | one of the conditions above |
| `minutesSinceRainStart` | number | optional |
| `dryHoursBefore` | number | optional |
| `month` | number | 1–12 |
| `windSpeed` | number | km/h, optional |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `weatherSpeedFactor(weather, ctx)` | number | 0.40 – 1.00 |
| `weatherCapacityFactor(weather, ctx)` | number | 0.55 – 1.00 |
| `inferWeather(month, wind, dryHours)` | string | auto-detection |

---

## CODE SHAPE

```
weatherSpeedFactor(weather, ctx?)    -> number
weatherCapacityFactor(weather, ctx?) -> number
inferWeather(ctx)                    -> string
WEATHER_TABLE                        -> exported for override
```

**Constraint:** both factors must be in `(0, 1]` and must never be zero. A
zero-speed road does not exist.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `clear` | both factors exactly 1.00 |
| `heavy_rain` | speed factor 0.75 – 0.82 |
| All conditions | both factors > 0 |
| `f_speed` ordering | clear > light_rain > rain > heavy_rain > snow_light > snow_heavy |
| First-rain rule | factor strictly lower than steady rain |
| Combined with F06 | rain increases travel time, never decreases it |

---

## NOTES

- **Weather is the most relatable factor in the whole model.** A judge or resident
  does not need to understand BPR to understand "rain makes it slower".
  Use weather as the *entry point* when explaining the model to a non-technical
  audience, then reveal that it feeds a proper speed-flow curve underneath.

- Weather data is **forecast, not measured**, when it comes from an API. Tag it
  `FORECAST`. Tag historical observations `MEASURED`.

- Do not attempt flood interaction here. Surface flooding belongs with the
  terrain model, not the traffic model — but the two should share the same rain
  event so a "heavy rain" scenario moves both the flood layer and the traffic
  layer together. **That coupling is a strong demo moment.**
