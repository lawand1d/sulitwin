# F09 — Incidents

**Real-time conditions → accidents, breakdowns, debris**

## PURPOSE

Models the capacity loss and duration of a blockage — a crash, a breakdown, a
spill, roadworks. Distinct from a planned closure (which is F11's input) because
incidents have a **random onset, a duration distribution, and partial capacity
loss** rather than a clean 0/1.

---

## EQUATION

```
C_incident = C_F05 × f_incident(lanesBlocked, totalLanes)

T_total = T_detect + T_respond + T_clear + T_recover
```

### 1. Capacity remaining — HCM incident factors

Fraction of capacity that remains when lanes are blocked:

| Total lanes | Shoulder only | 1 lane blocked | 2 lanes blocked | 3 lanes blocked |
|---|---|---|---|---|
| 1 | 0.85 | 0.05 | — | — |
| 2 | 0.81 | 0.35 | 0.05 | — |
| 3 | 0.83 | **0.49** | 0.17 | 0.05 |
| 4 | 0.85 | 0.58 | 0.25 | 0.13 |

**Even a single blocked lane on a 3-lane road removes half the capacity.** This is
why one crash can paralyse a corridor, and it is the most counter-intuitive
number in the model — worth stating explicitly to a non-technical audience.

### 2. Duration components

| Phase | Meaning | Typical |
|---|---|---|
| `T_detect` | until anyone knows | 2–5 min |
| `T_respond` | until units arrive | 4–10 min |
| `T_clear` | until lanes reopen | 10–45 min |
| `T_recover` | until flow returns to normal | 5–20 min |

```
T_clear ~ LogNormal(μ, σ)   — heavy-tailed, most are short, a few are long
```

| Severity | Lanes blocked | `T_clear` mean | σ |
|---|---|---|---|
| Minor (breakdown) | shoulder | 8 min | 5 |
| Moderate | 1 | 22 min | 15 |
| Major (injury crash) | 2 | 55 min | 40 |
| Severe (fatality / spill) | 3+ | 120 min | 90 |

### 3. Onset and recovery shape

Incident impact is not a step function. Use a raised-cosine ramp:

```
impact(τ) = 0.5 · (1 − cos(π · min(1, τ / RAMP)))      while the incident is active
```

with `RAMP` ≈ 0.15 × `T_total` at each end. This prevents an unrealistic instant
jam and instant recovery.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `f_incident` | HCM capacity table | above | STANDARD | — |
| `T_detect/respond/clear/recover` | duration model | tables above | ESTIMATED | police / incident logs |
| `RAMP` | ramp fraction | 0.15 | ESTIMATED | observation |
| `incidentRate` | incidents per 1000 veh-km | **0.35** | ESTIMATED | police collision records |

---

## INCIDENT RATES (for unplanned events)

If simulating a typical day, incidents can be generated stochastically:

```
P(incident on segment) = incidentRate × lengthKm × q / 1000 × Δt
```

`incidentRate = 0.35` per 1000 vehicle-kilometres is a mid-range urban estimate.
**Use a seeded PRNG**, never `Math.random()`, so the demo is repeatable.

Expected incidents in the demo block on a weekday: **0 to 1**. That is realistic
and worth saying — a model that generates five incidents a day in an 800 m block
is not credible.

---

## INPUTS

| Input | Type |
|---|---|
| `incidents` | `[{ roadId, lanesBlocked, totalLanes, severity, start, duration? }]` |
| `t` | number |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `incidentCapacityFactor(road, t, incidents)` | number | 1.0 if clear, down to 0.05 |
| `incidentDelaySeconds(road, t)` | number | extra delay attributable |
| `activeIncidents(t)` | array | |
| `generateTypicalIncidents(day, seed)` | array | for simulation mode |

---

## CODE SHAPE

```
incidentCapacityFactor(road, t, incidents) -> number
incidentSeverityToLanes(severity)          -> number
incidentDuration(severity, rng)            -> number  seconds
activeIncidents(t, incidents)              -> array
INCIDENT_CAPACITY_TABLE                    -> exported
```

**Constraint:** `incidentCapacityFactor` returns exactly `1.0` when no incident is
active. It must never return 0 — a fully closed road is a **closure**, which is a
different input (F11/`conditions.closures`). Keeping them separate prevents the
"division by zero" class of bug.

---

## VALIDATION

| Test | Expectation |
|---|---|
| No incidents | factor exactly 1.0 |
| 1 of 3 lanes | factor ≈ 0.49 |
| 2 of 3 lanes | factor ≈ 0.17 |
| Factor | always > 0 |
| Duration | mean within the table range; heavy tail present |
| Same seed twice | identical incidents (determinism) |
| Ramp shape | impact starts at 0, not at full effect |

---

## NOTES

- **Distinguish incident from closure everywhere in code and in the UI.** An
  incident is "we don't know how long". A closure is "by decision, until further
  notice". They produce the same congestion but mean completely different things
  to a planner, and the AI's reasoning must not confuse them.

- **Allow manual entry.** Real incidents are the one input that cannot be
  modelled ahead of time. Let a user type "crash blocking one lane on Salim
  Street" and re-run. That is the single most useful interactive feature this
  model enables, and it takes almost no extra code once F09 exists.

- The `T_recover` phase is frequently omitted and it matters: a road stays
  congested for 10–20 minutes *after* the lanes reopen, because the queue has to
  drain. That drain is **F10**.
