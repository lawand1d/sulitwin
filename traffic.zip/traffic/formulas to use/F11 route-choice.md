# F11 — Route choice

**User context → preferred route type · Alternative routes → comparison, tolls, distance tradeoffs**

## PURPOSE

Decides how traffic distributes across competing routes, and produces the ranked
alternatives a user is shown.

Both the aggregate question ("where does the traffic actually go?") and the
individual question ("what are my options?") use the same equation.

---

## EQUATION — multinomial logit

```
                exp( −θ · Cᵢ )
   P(i)  =  ─────────────────────
              Σⱼ exp( −θ · Cⱼ )
```

| Symbol | Meaning |
|---|---|
| `P(i)` | probability a driver chooses route `i` |
| `Cᵢ` | generalised cost of route `i`, in **minutes** |
| `θ` | dispersion parameter — how rationally drivers behave |

### Generalised cost

```
C = w_time · T          travel time, minutes          ← dominant term
  + w_dist · D          distance, km
  + w_toll · F          toll cost converted to minutes
  + w_risk · R          incident/closure exposure, 0–1
  + w_turn · N          number of turns (junction penalty)
```

Default weights — **all in minutes**, so they are directly comparable:

| Weight | Value | Meaning |
|---|---|---|
| `w_time` | 1.00 | one minute of travel time = one minute |
| `w_dist` | 0.35 | min per km — fuel, wear, effort |
| `w_toll` | value-of-time conversion | `toll / VOT`, VOT ≈ 3,000 IQD/h |
| `w_risk` | 2.5 | min per unit of incident exposure |
| `w_turn` | 0.20 | min per turn — intersections cost more than distance suggests |

### Dispersion `θ`

| `θ` | Behaviour |
|---|---|
| → 0 | drivers choose at random, ignoring cost |
| 0.1 | realistic urban mixed traffic |
| → ∞ | all drivers pick the single cheapest route (all-or-nothing) |

**Use `θ = 0.1` as the default.** This produces a sensible spread: the fastest
route takes most but not all traffic, which matches observation.

### Path-size correction (important in grid cities)

Plain logit over-counts overlap: three routes that share 80% of their length look
like three independent choices. Correct with a path-size term:

```
PS_i = Σ_a  (len_a / Len_i) · 1 / Σ_{j∈routes using a} P_j
```

Include it. In a dense grid like central Sulaimani, overlapping routes are the
norm and uncorrected logit will badly misallocate traffic.

---

## Equilibrium (for network loading)

Route choice and congestion are circular: congestion changes costs, which changes
choices, which changes congestion. Solve by **iterative assignment**:

```
repeat K times (K = 8 is plenty):
    1. Compute costs Cᵢ from current link flows (via F06, F07, F10)
    2. Recompute P(i) by logit
    3. Update flows:  q_new = (1 − λ)·q_old + λ·(assigned flows)
       with λ = 0.5 (method of successive averages)
until flows change by < 1%
```

**This is the most expensive part of the model.** For an 800 m demo block with a
few hundred links it runs in well under a second. For the whole city it would
need real traffic-assignment software. Document that boundary.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `θ` | logit dispersion | 0.1 | ESTIMATED | revealed-preference study |
| `w_time` | time weight | 1.00 | STANDARD | — |
| `w_dist` | distance weight | 0.35 | ESTIMATED | stated-preference survey |
| `w_risk` | risk weight | 2.5 | ESTIMATED | survey |
| `w_turn` | turn penalty | 0.20 | ESTIMATED | survey |
| `VOT` | value of time | 3,000 IQD/h | ESTIMATED | income data |
| `K` | assignment iterations | 8 | STANDARD | convergence |
| `λ` | MSA step | 0.5 | STANDARD | — |

Reference values from the literature put `θ` for urban route choice in the range
0.05–0.2. `0.1` is the centre of that range. Say so if asked.

---

## USER CONTEXT (from `private/P04`)

The weights are **modified per user**, which is what makes route *options* mean
something:

| Preference | Modification |
|---|---|
| Fastest | defaults |
| Shortest | `w_dist × 2.5`, `w_time × 0.6` |
| Safest | `w_risk × 4`, `w_turn × 1.5` |
| Avoid hills | add `w_slope` from the DEM gradient |
| Avoid signals | `w_turn × 3` at signalised junctions only |

---

## INPUTS

| Input | Type |
|---|---|
| `routes` | array of candidate routes, each with time / distance / toll / turn count |
| `preferences` | from P04 |
| `VOT` | number, optional |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `probabilities` | number[] | sums to exactly 1.0 |
| `assignedFlow` | number[] | veh/h per route |
| `rankedOptions` | array | for display, best first |
| `tradeoffText` | string key | e.g. `'slower_but_shorter'` — for the AI to render |

---

## CODE SHAPE

```
generalisedCost(route, weights)         -> number  (minutes)
routeProbabilities(routes, theta)       -> number[]
assignFlows(routes, totalDemand, theta) -> { probabilities, flows }
equilibriumIterate(network, K, lambda)  -> network with updated flows
rankAlternatives(routes, preferences)   -> sorted array
```

**Constraint:** `probabilities` must sum to exactly 1.0 (within 1e-9) and no
element may be `NaN`. Guard the exponent — `exp(−θ·C)` underflows for large `C`.
Subtract the minimum cost before exponentiating; this is a standard log-sum-exp
trick and it is not optional.

---

## VALIDATION

| Test | Expectation |
|---|---|
| Two identical routes | each probability exactly 0.5 |
| One route 10 min faster | its probability > 0.8 |
| Probabilities | sum to 1.0 ± 1e-9 |
| Very large cost difference | no `NaN`, no `Infinity` (log-sum-exp) |
| `θ → 0` | probabilities converge to uniform |
| Overlapping routes | path-size correction reduces the overlap bias |
| Equilibrium | converges in ≤ K iterations to < 1% change |

---

## NOTES

- **Log-sum-exp is the trap.** With `θ = 0.1` and costs around 30 minutes,
  `exp(−3)` is fine. With default weights and a long detour, `exp(−50)` underflows
  to zero and the whole distribution becomes `0/0`. Subtract the minimum cost
  first, every time.

- **Alternative routes are a user-facing feature, not just an internal step.**
  `rankedOptions` is what powers "here are your three options" — and the
  `tradeoffText` key is what lets the AI say *"the second route is 4 minutes
  slower but 1.2 km shorter"* without inventing anything.

- **Toll costs return zero in Sulaimani** — there are no toll roads. Keep the
  parameter and the term in the equation. Deleting it would mean the model could
  not be reused for Erbil or for a future tolled bypass, and it costs nothing to
  leave a term that evaluates to zero.

- **Do not run full equilibrium inside the what-if loop.** Run it once per
  scenario, cache the result, and reuse. Recomputing on every animation frame
  will drop the frame rate.
