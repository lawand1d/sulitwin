# F01 — Daily demand profile

**Temporal factors → time of day patterns**

## PURPOSE

Returns how busy the network is at a given time of day, as a multiplier on
average demand, and how that traffic splits by direction.

This is the formula that makes the clock matter. Without it every hour looks the
same and the model is a static picture.

---

## EQUATION

### 1. Demand magnitude

Demand is a sum of Gaussian peaks over the 24-hour clock, plus a night floor:

```
D(t) = base + Σᵢ Aᵢ · exp( −(t − μᵢ)² / (2σᵢ²) )

then normalised:   D̂(t) = D(t) / max(D)
```

### 2. Directional split

Sulaimani has a strong inbound morning and outbound evening. Traffic heading
*toward* the city centre is:

```
f_in(t) = clamp( 0.5 + 0.30 · ( P₁(t) − P₂(t) ),  0.15,  0.85 )

where Pᵢ(t) = the normalised weight of peak i at time t
```

`f_out(t) = 1 − f_in(t)`

---

## Why three peaks, not two

Most traffic models assume two peaks. That is wrong for Sulaimani and getting it
wrong makes the whole model look foreign.

Sulaimani has a distinct **late-evening social peak** — families visit, shop and
eat out after the heat drops. Shops stay open late. The bazaar and Salim Street
are busy at 21:00 in a way they are not at 14:00.

| Peak | Centre μ | Width σ | Height A | What it is |
|---|---|---|---|---|
| Night floor | — | — | 0.06 | 02:00–05:00 baseline |
| **Morning commute** | 08:00 | 0.70 h | 0.80 | school run + government start |
| **Afternoon release** | 16:15 | 0.90 h | 0.70 | school out + offices close |
| **Evening social** | 21:00 | 1.30 h | 0.45 | visiting, shopping, dining |

The evening peak is *wide* (σ = 1.3 h) rather than sharp — it is a spread of
social trips, not a synchronised commute. That shape difference is deliberate.

---

## PARAMETERS

| Symbol | Meaning | Value used | Provenance | Real source that replaces it |
|---|---|---|---|---|
| `base` | night-time floor | 0.06 | ESTIMATED | 24-hour counts |
| `μ₁ σ₁ A₁` | morning peak | 8.0, 0.70, 0.80 | ESTIMATED | hourly counts |
| `μ₂ σ₂ A₂` | afternoon peak | 16.25, 0.90, 0.70 | ESTIMATED | hourly counts |
| `μ₃ σ₃ A₃` | evening social peak | 21.0, 1.30, 0.45 | ESTIMATED | hourly counts |
| `dirAmp` | directional amplitude | 0.30 | ESTIMATED | directional counts |
| `centreLat/Lon` | the "toward centre" reference | 35.5571, 45.4430 | MEASURED | city centre definition |

`μ₁`, `μ₂`, `μ₃` are the highest-value calibration targets in the entire model.
One week of hourly counts at two or three junctions pins all three.

---

## INPUTS

| Input | Type | Range | Notes |
|---|---|---|---|
| `t` | number | 0 ≤ t < 24 | local clock hours, fractional (08:30 = 8.5) |
| `direction` | `'in' \| 'out' \| null` | — | null returns magnitude only |

## OUTPUTS

| Output | Type | Range | Meaning |
|---|---|---|---|
| `D̂(t)` | number | 0.06 – 1.0 | demand multiplier on average flow |
| `f_in(t)` | number | 0.15 – 0.85 | share heading toward the centre |
| `peakLabel(t)` | string | — | `'am_peak' \| 'pm_peak' \| 'evening' \| 'offpeak' \| 'night'` |

`peakLabel` exists so the AI can say *"this is the 08:00 inbound peak"* without
recomputing anything. It also drives the badge caption.

---

## CODE SHAPE

```
demandAt(t)                  -> number in [0.06, 1.0]
directionalSplit(t)          -> number in [0.15, 0.85]   (share inbound)
peakLabel(t)                 -> string
PEAKS                        -> the parameter table above, exported for override
```

**Constraint:** all four exports must be pure functions of `t`. No `Date.now()`
inside — the caller supplies the clock. This is what lets the slider work.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `demandAt(8)` | ≥ 0.95 — it is the morning peak |
| `demandAt(3)` | ≤ 0.10 — it is the middle of the night |
| `demandAt(21)` | ≥ 0.45 — the social peak must be visible |
| `demandAt` over 24 h | exactly one global maximum |
| `directionalSplit(8)` | > 0.6 — inbound in the morning |
| `directionalSplit(16.25)` | < 0.4 — outbound in the afternoon |
| `directionalSplit(12)` | ≈ 0.5 ± 0.08 |
| Sum over 24 h | matches the daily total within 5% |

---

## NOTES

- **Times are local clock hours, not UTC.** Sulaimani is UTC+3, no daylight
  saving. Do not apply a timezone conversion inside the formula; do it once at
  the boundary.
- **Curve shape is more important than peak height.** If real counts later show
  the peaks are at 07:30 and 17:00, move `μ`, do not rescale `A`. The shape tells
  the story; the amplitude is just a scale factor.
- **Ramadan changes this curve entirely** — see F03. During Ramadan the shape is
  replaced, not merely scaled.
- The evening peak at 21:00 is the one most likely to be wrong in the estimate.
  It is also the one a Sulaimani judge will immediately recognise as right or
  wrong. **Ask a local before Demo Day.**
