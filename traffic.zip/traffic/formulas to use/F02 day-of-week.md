# F02 — Day of week

**Temporal factors → day of week**

## PURPOSE

Returns the demand multiplier for a day of the week, and flags whether that day
needs a *different profile shape* rather than just a different scale.

---

## The local week (get this right — it is the most visible local detail)

The Kurdistan Region works **Sunday to Thursday**. The weekend is **Friday and
Saturday**. This is the opposite of the Western assumption and getting it wrong
makes the model obviously foreign to a Sulaimani audience.

| Day | Index | Character |
|---|---|---|
| Sunday | 0 | Full working day. Normal double peak. |
| Monday | 1 | Full working day. Normal double peak. |
| Tuesday | 2 | Full working day. Normal double peak. |
| Wednesday | 3 | Full working day. Slightly heaviest of the four. |
| **Thursday** | 4 | **Weekend eve.** Offices close early, travel to family begins. Evening peak starts ~2 h earlier and runs later. |
| **Friday** | 5 | **Weekend + holy day.** Morning is dead. Sharp midday spike at Friday prayers. Strong evening social. Needs its own curve. |
| **Saturday** | 6 | Weekend, but shops and many businesses open. Single broad midday-to-evening hump, no commute peak. |

---

## EQUATION

### Magnitude multiplier

```
W(d) = TABLE[d]
```

### Shape override

Friday and Saturday are not scaled versions of a weekday. They use **different
peak parameters in F01**:

```
if d == FRIDAY:      use FRIDAY_PEAKS instead of PEAKS
else if d == SATURDAY: use SATURDAY_PEAKS
else if d == THURSDAY: use THURSDAY_PEAKS
else:                use PEAKS (F01 default)
```

---

## PARAMETERS

### Magnitude table

| Day | Index | `W(d)` | Provenance |
|---|---|---|---|
| Sunday | 0 | 1.00 | ESTIMATED |
| Monday | 1 | 1.00 | ESTIMATED |
| Tuesday | 2 | 1.00 | ESTIMATED |
| Wednesday | 3 | 1.02 | ESTIMATED |
| Thursday | 4 | 1.05 | ESTIMATED |
| Friday | 5 | 0.55 | ESTIMATED |
| Saturday | 6 | 0.80 | ESTIMATED |

### Profile overrides

**Thursday** — evening peak moves earlier and widens:

| Peak | μ | σ | A |
|---|---|---|---|
| Morning | 8.0 | 0.70 | 0.78 |
| Afternoon | 15.0 | 1.20 | 0.72 |
| Evening | 20.0 | 1.80 | 0.62 |

**Friday** — no commute at all; a prayers spike and a long social evening:

| Peak | μ | σ | A |
|---|---|---|---|
| Prayer spike | 12.4 | 0.55 | 0.85 |
| Evening social | 20.5 | 2.00 | 0.70 |
| Late | 23.0 | 1.20 | 0.35 |

**Saturday** — one broad daytime hump, no commute:

| Peak | μ | σ | A |
|---|---|---|---|
| Midday | 13.0 | 2.20 | 0.80 |
| Evening | 20.5 | 1.80 | 0.65 |

| Symbol | Meaning | Value | Real source |
|---|---|---|---|
| `TABLE` | day multipliers | above | 7-day classified counts |
| `*_PEAKS` | per-day peak sets | above | 7-day hourly counts |

---

## INPUTS

| Input | Type | Notes |
|---|---|---|
| `d` | number 0–6 | 0 = Sunday, matching the local week |
| `date` | Date | optional, used only to detect public holidays — see below |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `dayFactor(d)` | number | magnitude multiplier |
| `peaksFor(d)` | peak-set | the F01 parameter set to use |
| `dayType(d)` | string | `'weekday' \| 'thursday' \| 'friday' \| 'saturday' \| 'holiday'` |

---

## CODE SHAPE

```
dayFactor(d)        -> number
peaksFor(d)         -> { base, peaks: [{mu, sigma, amp}, ...] }
dayType(d)          -> string
DAY_TABLE           -> exported for override
```

**Constraint:** `dayFactor` must not call F01. It returns a multiplier; F01 is
then called *with* `peaksFor(d)`. Keep the dependency one-way.

---

## VALIDATION

| Test | Expectation |
|---|---|
| `dayFactor(5)` (Friday) | < 0.70 — the quietest day |
| `dayFactor(4)` (Thursday) | > `dayFactor(1)` — weekend eve is busier |
| `peaksFor(5)` | has no peak within ±1 h of 08:00 — no Friday commute |
| `peaksFor(5)` | has a peak within ±0.5 h of 12.4 — prayers |
| `peaksFor(6)` | maximum peak is broader than a weekday (σ ≥ 2.0) |
| `dayType(4)` | `'thursday'` |

---

## NOTES

- **Public holidays are a separate concern.** Kurdish holidays (Nowruz, Eid,
  Martyrs' Day, etc.) behave like a Friday or quieter. Detect them from a date
  table, set `dayType = 'holiday'`, and reuse the Friday profile. The holiday
  date table is owned by **F03**, not here — F02 handles the weekly cycle only.
- **Thursday is the sleeper detail.** It is the day a Sulaimani judge will notice
  you got right. Its traffic signature — early release, early evening peak — is
  distinctive and nobody outside the region models it.
- If real 7-day counts later disagree with `TABLE`, replace `TABLE` and keep the
  peak overrides. The *shape* of a Friday is more robust than its magnitude.
