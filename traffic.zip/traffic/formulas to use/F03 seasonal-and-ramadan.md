# F03 — Seasonal variation, Ramadan and holidays

**Temporal factors → seasonal variations, holiday traffic**

## PURPOSE

Returns the seasonal demand multiplier and, critically, decides whether to
**replace the daily profile entirely** rather than scale it.

Ramadan is the reason this file exists. During Ramadan the shape of a Sulaimani
traffic day inverts. Scaling the normal curve would produce an obviously wrong
model.

---

## EQUATION

```
S(date) = seasonFactor(date.season) × ramadanFactor(date) × holidayFactor(date)

profileFor(date) =  RAMADAN_PEAKS   if isRamadan(date)
                 |  SUMMER_PEAKS    if isSummer(date) and not isRamadan
                 |  EID_PEAKS       if isEid(date)
                 |  peaksFor(dayOfWeek)   otherwise    ← from F02
```

---

## 1. Seasonal baseline

| Season | Months | Factor | Character |
|---|---|---|---|
| Winter | Dec – Feb | 0.95 | School in session. Rain and occasional snow. |
| Spring | Mar – May | 1.00 | Baseline. Nowruz falls here. |
| **Summer** | Jun – Aug | **0.80** | School out, 38–42 °C. Trips shift to the cool hours. |
| Autumn | Sep – Nov | 1.00 | School returns. Baseline. |

**Summer is not just quieter — it moves.** The commute peak pulls earlier
(people travel before the heat) and the social peak pushes later:

| Peak | Normal μ | Summer μ | σ |
|---|---|---|---|
| Morning | 8.00 | **7.00** | 0.80 |
| Afternoon | 16.25 | **17.00** | 1.00 |
| Evening social | 21.00 | **22.00** | 1.60 |

---

## 2. Ramadan — the profile inverts

Ramadan is a lunar month and moves **≈11 days earlier each Gregorian year**. It
cannot be hard-coded to a month; it needs a date table (`RAMADAN_RANGES`), which
must be updated yearly.

During Ramadan in Kurdistan:

- Working hours shorten (typically ~09:00–14:00)
- Daytime traffic collapses — people sleep late and avoid the heat without water
- **Iftar spike**: a violent surge in the 60–90 minutes before sunset
- After iftar: a long, heavy social period — visiting, shopping, taraweeh prayers
- **Suhoor** (~03:00–04:00): a moderate pre-dawn peak
- The last ten nights are heavier than the first twenty

### Ramadan peak set

Note that the peak times depend on **sunset**, which varies from ~17:30 (winter
Ramadan) to ~19:15 (summer Ramadan). Express the iftar spike as an offset from
sunset, not a fixed clock hour.

| Peak | Definition | μ offset | σ | A |
|---|---|---|---|---|
| Suhoor | — | 03.5 | 0.90 | 0.30 |
| (daytime) | — | — | — | **0.10 floor** |
| **Iftar** | sunset − 0.5 h | *computed* | 0.55 | **1.00** |
| Post-iftar social | sunset + 2.5 h | *computed* | 1.60 | 0.75 |
| Late night | sunset + 5.0 h | *computed* | 1.20 | 0.40 |

Overall Ramadan magnitude factor: **0.85** (lower daily total, far higher peaks).

### Sunset calculation

Needs a solar position routine (NOAA algorithm, ~40 lines) using Sulaimani's
coordinates (35.5571 N, 45.4430 E, UTC+3). Do **not** hard-code sunset times.

---

## 3. Holidays

| Holiday | Approx. date | Profile | Factor |
|---|---|---|---|
| Nowruz (Kurdish New Year) | 20–22 Mar | Friday-like, plus street celebration peaks | 0.70 |
| Eid al-Fitr | 1 Shawwal (3 days) | Morning dead, heavy visiting 10:00–14:00 and evening | 0.75 |
| Eid al-Adha | 10 Dhu al-Hijjah (4 days) | As above, plus inter-city travel | 0.75 |
| Martyrs' Day | 16 Mar | Memorial, low traffic | 0.70 |
| Kurdistan Flag Day | 17 Dec | Low | 0.85 |
| New Year | 1 Jan | Retail peaks | 1.10 |

Eid dates are lunar and must come from a table, same as Ramadan.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `seasonFactor` | seasonal multipliers | table above | ESTIMATED | annual counts |
| `SUMMER_PEAKS` | shifted summer profile | table above | ESTIMATED | seasonal counts |
| `RAMADAN_PEAKS` | replacement profile | table above | ESTIMATED | Ramadan counts |
| `RAMADAN_RANGES` | lunar date ranges | must be updated yearly | MEASURED (calendar) | published calendars |
| `EID_DATES` | Eid date table | must be updated yearly | MEASURED (calendar) | published calendars |
| `sunset()` | solar position | NOAA algorithm | MEASURED (astronomy) | — |

---

## INPUTS

| Input | Type |
|---|---|
| `date` | Date |
| `lat`, `lon` | numbers, for sunset |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `seasonFactor(date)` | number | baseline multiplier |
| `profileFor(date)` | peak-set | which F01 parameters to use |
| `seasonLabel(date)` | string | `'normal' \| 'ramadan' \| 'summer' \| 'eid' \| 'nowruz'` |

---

## CODE SHAPE

```
seasonFactor(date)          -> number
profileFor(date)            -> peak-set
seasonLabel(date)           -> string
sunsetUTC(date, lat, lon)   -> Date
RAMADAN_RANGES              -> exported table
HOLIDAY_TABLE               -> exported table
```

---

## VALIDATION

| Test | Expectation |
|---|---|
| `profileFor(ramadanDate)` | has a peak within 1 h of that day's sunset |
| `profileFor(ramadanDate)` | daytime hours 10:00–15:00 all < 0.20 |
| `sunsetUTC` for 15 Jul | between 16:00 and 17:30 UTC |
| `sunsetUTC` for 15 Jan | between 13:30 and 15:00 UTC |
| `seasonLabel` in July | `'summer'` |
| Summer morning peak μ | < 7.5 (earlier than normal) |
| `RAMADAN_RANGES` covers the next 3 years | true |

---

## NOTES

- **"Ramadan" means the Islamic month, not a fixed date.** Any implementation
  that hard-codes "Ramadan = June" is wrong within two years.
- The Ramadan table **must be maintained**. Put an explicit comment saying so, and
  make the function fail loudly — not silently fall back to a normal day — if a
  requested date falls outside the table. A silently wrong model is worse than a
  crash.
- **The iftar spike is the single most distinctive thing about traffic in this
  region.** If you demo one seasonal feature, demo this one: drag the clock
  slider to 30 minutes before sunset in Ramadan and watch the network lock up,
  then go empty an hour later.
- Summer heat is a genuine sustainability story: it is also *why* tree planting
  and shade matter. The traffic model and the heat model share a cause.
