# F05 — Road capacity

**Road network factors → capacity, lanes, width, road type**

## PURPOSE

Returns the practical capacity of a road in vehicles per hour, derived from OSM
tags where they exist and from road class where they do not.

Capacity is the denominator of everything. Every congestion number in the model
is `demand ÷ capacity`, so an error here propagates everywhere.

---

## EQUATION

```
C = N_lanes × C_lane × f_w × f_hv × f_terrain × f_side
```

| Term | Meaning |
|---|---|
| `N_lanes` | usable lanes in the direction of travel |
| `C_lane` | ideal saturation flow per lane ≈ **1900** pc/h |
| `f_w` | lane width adjustment |
| `f_hv` | heavy-vehicle adjustment |
| `f_terrain` | terrain adjustment |
| `f_side` | roadside friction (parking, vendors, pedestrians) |

---

## 1. Lane count

OSM's `lanes` tag is **missing on most roads**. Infer it:

```
if lanes tag present:      N = round(lanes / (oneway ? 1 : 2))
else:                      N = CLASS_DEFAULT_LANES[highway]
```

| OSM class | Default lanes **per direction** | Notes |
|---|---|---|
| motorway | 2 | |
| trunk | 2 | |
| primary | 2 | |
| primary_link | 1 | |
| secondary | 1 | |
| secondary_link | 1 | |
| tertiary | 1 | |
| tertiary_link | 1 | |
| residential | 1 | Sulaimani residential is often 1 effective lane |
| unclassified | 1 | |
| living_street | 1 | effectively shared, low capacity |
| service | 1 | |

**Bidirectional roads divide by two.** A residential road tagged `lanes=2` is one
lane each way, not two each way.

---

## 2. Lane width adjustment `f_w`

OSM `width` is rarely present. Estimate **3.2 m** as the local default — Sulaimani
streets are typically narrower than the 3.6 m HCM ideal.

| Effective lane width | `f_w` |
|---|---|
| ≥ 3.6 m | 1.00 |
| 3.3 m | 0.97 |
| 3.0 m | 0.93 |
| 2.8 m | 0.89 |
| 2.5 m | 0.82 |
| ≤ 2.3 m | 0.75 |

---

## 3. Heavy-vehicle adjustment `f_hv`

```
f_hv = 1 / (1 + P_hv × (E_hv − 1))
```

| Symbol | Meaning | Value | Notes |
|---|---|---|---|
| `P_hv` | share of heavy vehicles | 0.06 city centre, 0.12 arterial | ESTIMATED |
| `E_hv` | passenger-car equivalent | 2.0 level, 3.5 rolling, 5.0 mountainous | |

Sulaimani has a noticeable share of minibuses, pickups and small trucks operating
as shared transport. This is why `E_hv` matters here more than in a European city.

---

## 4. Terrain adjustment `f_terrain`

**This one is specific to Sulaimani and should not be left at the textbook
default.**

The city sits in a mountain basin. Our own DEM shows **59 m of relief across the
800 m demo block** and 616–1651 m across the wider municipal area. Gradients
reduce achievable speed and capacity.

| Terrain | `f_terrain` |
|---|---|
| Level (slope < 2°) | 1.00 |
| Rolling (2–6°) | 0.92 |
| Hilly (6–10°) | 0.85 |
| Mountainous (> 10°) | 0.76 |

**Compute the slope from the DEM per road segment.** The DEM already exists in
this project (10 m grid, UTM 38N, validated to ±1.2 m). A road's slope is the
mean gradient along its geometry.

This is a real, defensible local differentiator: the model accounts for the fact
that Sulaimani is built on hills, because we measured the hills.

---

## 5. Roadside friction `f_side`

| Situation | `f_side` |
|---|---|
| No parking, no frontage | 1.00 |
| Occasional kerbside parking | 0.92 |
| Continuous kerbside parking | 0.85 |
| Market / bazaar frontage | 0.75 |
| Street vendors present | 0.70 |

Detect from OSM where possible (presence of `shop`, `amenity=marketplace`,
`parking:lane`). Otherwise default to 0.90 in the city centre.

---

## PARAMETERS

| Symbol | Meaning | Value | Provenance | Real source |
|---|---|---|---|---|
| `C_lane` | ideal lane capacity | 1900 pc/h | ESTIMATED (HCM) | local saturation flow study |
| `CLASS_DEFAULT_LANES` | lane inference table | above | ESTIMATED | road inventory survey |
| `WIDTH_DEFAULT` | assumed lane width | 3.2 m | ESTIMATED | road inventory survey |
| `P_hv` | heavy vehicle share | 0.06 / 0.12 | ESTIMATED | classified counts |
| `f_terrain` | terrain factors | above | **MEASURED inputs** (DEM) | DEM + classification |
| `f_side` | friction factors | above | ESTIMATED | parking survey |

---

## INPUTS

| Input | Type | Notes |
|---|---|---|
| `road` | object | OSM tags: `highway`, `lanes`, `width`, `oneway`, `bridge`, `surface` |
| `slopeDeg` | number | optional, from DEM. Defaults to 0 → `f_terrain = 1` |

## OUTPUTS

| Output | Type | Meaning |
|---|---|---|
| `capacityOf(road)` | number | vehicles/hour, one direction |
| `capacityBreakdown(road)` | object | each factor separately, for explainability |
| `defaultLanes(highway)` | number | |
| `terrainFactor(slopeDeg)` | number | |

`capacityBreakdown` matters: when the AI says *"this road carries 900 vehicles an
hour"*, it should be able to say *why* — 1 lane × 1900 × 0.89 width × 0.94 heavy
× 0.85 hill × 0.90 parking.

---

## CODE SHAPE

```
capacityOf(road, slopeDeg?)      -> number
capacityBreakdown(road, slopeDeg?) -> { lanes, cLane, fw, fhv, fterrain, fside, total }
defaultLanes(highway)            -> number
terrainFactor(slopeDeg)          -> number
CLASS_DEFAULT_LANES              -> exported table
```

**Constraint:** `capacityOf` must be pure and cheap. It is called for every road
on every time step. Cache the result per road — it does not change with time.

---

## VALIDATION

| Test | Expectation |
|---|---|
| Residential, 1 lane | 900 – 1500 veh/h |
| Primary, 2 lanes | 2400 – 3400 veh/h |
| Motorway, 2 lanes | 3400 – 3800 veh/h |
| Doubling lanes | doubles capacity |
| Steep road (> 10°) | capacity ≤ 78% of the level road |
| `capacityBreakdown` | product of factors equals `capacityOf` exactly |
| Every road in the block | > 0 (no road may be un-capacitated) |

---

## NOTES

- **Do not let capacity become zero.** A road with terrible factors still carries
  some traffic. Floor it at 150 veh/h so division never explodes.
- The terrain factor is the one genuinely original piece here. Most traffic models
  treat a city as flat. Sulaimani is not flat, we have the DEM to prove it, and
  the gradient materially changes what a road can carry.
- If a full road inventory ever arrives, `CLASS_DEFAULT_LANES` and `WIDTH_DEFAULT`
  are the two tables it replaces. Nothing else changes.
