# DATA CONTRACT

Every input this model needs, what value is used today, and exactly what real
data would replace it.

**The rule:** if a number appears in more than one file, it is wrong. Each
parameter is declared once, in the file that owns it, and imported everywhere
else.

---

## Part 1 — Inputs we can get from open data TODAY

These are already available and should not be estimated.

| # | Input | Source | Format | Owner file |
|---|---|---|---|---|
| D1 | Road geometry | OpenStreetMap | GeoJSON LineStrings | `F05` |
| D2 | Road class (`highway`) | OpenStreetMap | tag | `F05` |
| D3 | Lane count (`lanes`) | OpenStreetMap | tag, often absent | `F05` |
| D4 | Road width (`width`) | OpenStreetMap | tag, mostly absent | `F05` |
| D5 | One-way (`oneway`) | OpenStreetMap | tag | `F05` |
| D6 | Speed limit (`maxspeed`) | OpenStreetMap | tag, mostly absent | `F05` |
| D7 | Traffic signals | OpenStreetMap `highway=traffic_signals` | nodes | `F07` |
| D8 | Bus stops | OpenStreetMap | nodes | `B02` |
| D9 | Bus routes | OpenStreetMap route relations | relations | `B01` |
| D10 | Bridge / tunnel | OpenStreetMap | tags | `F05` |
| D11 | Surface type | OpenStreetMap | tag | `F05` |

**Action:** run a single Overpass query for D7 and D9 over the demo block and
commit the result. We already have D1–D6, D8, D10.

---

## Part 2 — Inputs that must be ESTIMATED until real data exists

Every one of these is a **table of constants**, never a hard-coded value inside
a formula. This is what makes the model swappable.

| # | Input | Estimated today | Real source that replaces it | Owner file |
|---|---|---|---|---|
| E1 | Peak hour centres | 08:00 and 16:30 | Municipal traffic counts | `F01` |
| E2 | Peak magnitudes | see F01 table | Municipal traffic counts | `F01` |
| E3 | Directional split | see F01 | Directional counts | `F01` |
| E4 | Day-of-week factors | see F02 table | Multi-day counts | `F02` |
| E5 | Seasonal factors | see F03 table | Annual counts | `F03` |
| E6 | Ramadan profile | see F03 | Ramadan-period counts | `F03` |
| E7 | Lane capacity | HCM defaults | Local saturation flow study | `F05` |
| E8 | Free-flow speeds | OSM class assumption | GPS probe data | `F05` |
| E9 | PCU equivalents | Standard values | Local vehicle-mix survey | `P01` |
| E10 | Signal cycle lengths | 60–120 s assumption | Signal controller logs | `F07` |
| E11 | Green-time ratios | 0.45–0.55 assumption | Signal controller logs | `F07` |
| E12 | Weather speed factors | see F08 | Matched rain/speed study | `F08` |
| E13 | Incident rates | see F09 | Police / incident logs | `F09` |
| E14 | Car occupancy | 1.4 | Roadside occupancy survey | `P02` |
| E15 | Parking search time | see `P03` | Parking survey | `P03` |
| E16 | Bus dwell time | see `B02` | AVL / APC data | `B02` |
| E17 | Bus headways | see `B03` | Operator timetable | `B03` |
| E18 | Bus occupancy | see `B04` | APC (automatic passenger count) | `B04` |
| E19 | Route-choice dispersion θ | 0.1 | Revealed-preference study | `F11` |
| E20 | Forecast smoothing α | 0.3 | Backtest against history | `F12` |

---

## Part 3 — Data we will never have (and must say so)

| # | Input | Why not | What to do instead |
|---|---|---|---|
| N1 | Live traffic speeds | No probe fleet, no public feed | Say "proxy". Never colour a road from invented live data. |
| N2 | Live incidents | No integration with police | Model *typical* incident rates; let a human enter actual events. |
| N3 | Real-time bus positions | No AVL feed | Show the timetable model, labelled as a timetable. |
| N4 | Signal timings | Not published | Use the HCM default cycle and say so. |
| N5 | Toll costs | No toll roads in Sulaimani | Keep the parameter; it returns 0. Documented, not deleted. |

**N1 is the important one.** It is the reason this entire model exists. We cannot
show live traffic, so we show a defensible *typical* traffic model and label it.
That is a stronger position than a fabricated live feed, and it is the honest one.

---

## Part 4 — The replacement procedure

When real data arrives, this is the entire migration. No formula changes.

```
STEP 1  Identify which parameter from Part 2 the dataset informs.
STEP 2  Open the owner file listed in the table.
STEP 3  Replace the numbers in that file's PARAMETERS table.
STEP 4  Change the provenance tag for that parameter from ESTIMATED to MEASURED.
STEP 5  Re-run the validation in VALIDATION.md against the new values.
STEP 6  Nothing else changes. Not one formula. Not one sentence of reasoning.
```

If step 6 is ever false — if swapping a number forces you to edit a formula —
the model was built wrong. Fix the structure, not the formula.

---

## Part 5 — Validation harness (what to build alongside)

To claim the model is correct you must be able to show it is wrong when it is.

| Test | Method | Pass condition |
|---|---|---|
| Capacity sanity | Sum network capacity, compare to a plausible vehicle fleet | Within 2× |
| Peak plausibility | Modelled peak v/c on the main corridor | 0.7 – 1.0 |
| Off-peak plausibility | Modelled 03:00 v/c | < 0.15 |
| Monotonicity | Increase demand by 10%, travel time must rise | Always true |
| Weather direction | Add rain, speeds must fall | Always true |
| Conservation | Vehicles entering = vehicles leaving (closed system) | Exact |
| LOS continuity | v/c 0.99 and 1.01 must not jump two grades | Adjacent only |
| Determinism | Same input twice, identical output | Exact |

These become unit tests. They are the same tests that appear in the project's
existing test suite, in the same style.
